/************************************************************************/
/*                                                                      */
/*    Beispielprogramm:                                 EVNT_KEYBD()    */
/*                                                                      */
/*    Copyright (c)  Heimsoeth & Borland  1988                          */
/*                                                                      */
/************************************************************************/

/* -------------------------------------------------------------------- */
/*    Include-Files einbinden.                                          */
/* -------------------------------------------------------------------- */

#include <aes.h>

#include "scancode.h"

/* -------------------------------------------------------------------- */
/*    test_fkt()                                          test function */
/*                                                                      */
/*    Funktion, die dem Austesten dient (hier: evnt_keybd()).           */
/* -------------------------------------------------------------------- */

void test_fkt()
{
   int kc = 0;

   while(kc != CNTRL_C)
   {
      kc = evnt_keybd();
      if(kc == CNTRL_C)
         form_alert(1, "[1][Programmende.][Ok]");
      else
         form_alert(1, "[2][Programm kann mit|Control-C|verlassen werden][Ok]");
   }
}

/* -------------------------------------------------------------------- */
/*    Ende der Beispielprogramms f�r EVNT_KEYBD().                      */
/* -------------------------------------------------------------------- */
