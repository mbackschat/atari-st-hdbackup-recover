/************************************************************************/
/*                                                                      */
/*    clock.c                                                           */
/*                                                                      */
/*    Beispielprogramm f�r Accessories.                                 */
/*    Durch blo�es �ndern der Extension im Dateinamen, l��t sich Pro-   */
/*    gramm als normale GEM-Anwendung oder aber als Accessory betrei-   */
/*    ben.                                                              */
/*    Das Programm zeigt in einem Fenster die aktuelle Uhrzeit und das  */
/*    Datum an.                                                         */
/*                                                                      */
/*    Copyright (c)  Heimsoeth & Borland  1988                          */
/*                                                                      */
/************************************************************************/

/* -------------------------------------------------------------------- */
/*    Headerdateien einbinden.                                          */
/* -------------------------------------------------------------------- */

#include <aes.h>
#include <stdio.h>
#include <tos.h>
#include <time.h>
#include <vdi.h>

/* -------------------------------------------------------------------- */
/*    Extern definierte globale Variablen.                              */
/* -------------------------------------------------------------------- */
                                    /* Mittels dieser Variablen kann    */
extern int _app;                    /* das Programm feststellen, ob es  */
                                    /* als Accessory oder normale App-  */
                                    /* likation gestartet wurde.        */
/* -------------------------------------------------------------------- */
/*    Globale Variablen.                                                */
/* -------------------------------------------------------------------- */

int  whandle;                       /* Handle f�r ge�ffnetes Fenster.   */
char title[] = "Clock in Turbo C";  /* Titelzeile des Fensters.         */
int  gl_wchar,                      /* Gr��e und Breite eines Buchsta-  */
     gl_hchar,                      /* ben (wichtig falls mit unter-    */
     gl_wbox,                       /* schiedlichen Bildschirmaufl�-    */
     gl_hbox;                       /* sungen gearbeitet wird) bzw.     */
                                    /* einer Box.                       */
int  phys_handle,                   /* Handles f�r GEM und VDI.         */
     handle;
int  max_x,                         /* Maximale Gr��e der Arbeitsfl�che */
     max_y;
int  appl_id,                       /* Identifikationsnummer des Prog.  */
     menu_id;                       /* Id.-nummer im Men� 'Desk'.       */

   union tosdate                    /* Union f�r das aktuelle Datum.    */
   {
      unsigned short             u;
      struct packed_date
      {
         unsigned year    : 7;
         unsigned month   : 4;
         unsigned day     : 5;
      }                          p;
   } dt;

   union tostime                    /* Union f�r die Startzeit des Pro- */
   {                                /* gramms.                          */
      unsigned short             u;
      struct packed_time
      {
         unsigned hour    : 5;
         unsigned minute  : 6;
         unsigned second2 : 5;
      }                          p;
   } tt;

int     ti_buff[3];                 /* Puffer f�r die aktuelle Zeit.    */
clock_t ti_semaphor;                /* 'Ampel' f�r 200 Hz Z�hler.       */

/* -------------------------------------------------------------------- */
/*    open_window()                                                     */
/*                                                                      */
/*    �ffnen eines Fensters f�r die Zeitanzeige.                        */
/* -------------------------------------------------------------------- */

void open_window( void )
{
   if(whandle <= 0)
   {
      whandle = wind_create( NAME|CLOSER|MOVER, 0, 0, max_x + 1, max_y + 1 );
      if( whandle <= 0 )
         return;

      wind_set ( whandle, WF_NAME, title );
      wind_open( whandle, 100, 100, 200, 70 );
   }
   else
      wind_set( whandle, WF_TOP );
}

/* -------------------------------------------------------------------- */
/*    min()                                                             */
/*                                                                      */
/*    Minimum zweier Zahlen berechnen.                                  */
/* -------------------------------------------------------------------- */

int min( int a, int b)
{
   if( a > b )
      return( b );
   else
      return( a );
}

/* -------------------------------------------------------------------- */
/*    max()                                                             */
/*                                                                      */
/*    Maximum zweier Zahlen bestimmen.                                  */
/* -------------------------------------------------------------------- */

int max( int a, int b)
{
   if( a < b )
      return( b );
   else
      return( a );
}

/* -------------------------------------------------------------------- */
/*    rc_intersect()                                                    */
/*                                                                      */
/*    Schnittfl�che zweier Rechtecke berechnen.                         */
/* -------------------------------------------------------------------- */

int rc_intersect(GRECT *r1, GRECT *r2)
{
   int xl, yu, xr, yd;                      /* left, upper, right, down */

   xl      = max( r1->g_x, r2->g_x );
   yu      = max( r1->g_y, r2->g_y );
   xr      = min( r1->g_x + r1->g_w, r2->g_x + r2->g_w );
   yd      = min( r1->g_y + r1->g_h, r2->g_y + r2->g_h );

   r2->g_x = xl;
   r2->g_y = yu;
   r2->g_w = xr - xl;
   r2->g_h = yd - yu;

   return( r2->g_w > 0 && r2->g_h > 0 );
}

/* -------------------------------------------------------------------- */
/*    mouse_on()                                                        */
/*                                                                      */
/*    Mauszeiger anschalten.                                            */
/* -------------------------------------------------------------------- */

void mouse_on(void)

{
   graf_mouse( M_ON, (void *)0 );
}

/* -------------------------------------------------------------------- */
/*    mouse_off()                                                       */
/*                                                                      */
/*    Mauszeiger ausschalten.                                           */
/* -------------------------------------------------------------------- */

void mouse_off(void)
{
   graf_mouse( M_OFF, (void *)0 );
}

/* -------------------------------------------------------------------- */
/*    redraw_window()                                                   */
/*                                                                      */
/*    Fensterinhalt neu zeichnen, nachdem er zuvor aus irgendeinem      */
/*    Grunde zerst�rt wurde, oder weil das Fenster neu ge�ffnet wurde.  */
/* -------------------------------------------------------------------- */

void redraw_window( int all )
{
   GRECT   box,
           work;
   int     clip[4];
   char    s[80];
   clock_t delta_ti,
           h_ti;

   if( whandle <= 0 )                  /* Wenn kein Fenster auf ist,    */
      return;                          /* brauch auch nicht gezeichnet  */
                                       /* zu werden.                    */

   if( (delta_ti = (h_ti = clock()) - ti_semaphor) > 200 )
   {
                                       /* Pr�fen, ob seit dem letzten   */
                                       /* Aufruf eine Sekunde vergangen */
                                       /* ist. Redraw nur durchf�hren,  */
                                       /* falls dies der Fall ist, oder */
                                       /* es ausdr�cklich verlangt ist. */

      dt.u = Tgetdate();               /* Aktuelles Datum bestimmen.    */
      dt.u = Tgetdate();               /* Aktuelles Datum bestimmen.    */

      ti_semaphor = h_ti - (delta_ti - (delta_ti / 200) * 200) + 1;

      if( delta_ti > 200 )
         if( ++ti_buff[0] == 60 )      /* Zeit um eine Sekunde erh�hen. */
         {
            ti_buff[0] = 0;
            if( ++ti_buff[1] == 60 )
            {
               ti_buff[1] = 0;
               if( ++ti_buff[2] == 24 )
                  ti_buff[2] = 0;
            }
         }
   }

   if(delta_ti > 200 || all)
   {
      sprintf(s,"   %d.%d.%d  %d:%02d:%02d", dt.p.day, dt.p.month,
              dt.p.year+1980, ti_buff[2], ti_buff[1], ti_buff[0] );

      mouse_off();

      vsf_color( handle, 0 );                       /* set white fill   */
      vswr_mode( handle, 1 );                       /* set replace mode */

      wind_get( whandle, WF_WORKXYWH, &work.g_x, &work.g_y, &work.g_w,
                &work.g_h );
      wind_get( whandle, WF_FIRSTXYWH, &box.g_x, &box.g_y, &box.g_w,
                &box.g_h );
      work.g_w = min( work.g_w, max_x - work.g_x + 1 );
      work.g_h = min( work.g_h, max_y - work.g_y + 1 );

      while ( box.g_w > 0 && box.g_h > 0 )
      {
         if( rc_intersect( &work, &box ) )
         {
            clip[0] = box.g_x;
            clip[1] = box.g_y;
            clip[2] = box.g_x + box.g_w - 1;
            clip[3] = box.g_y + box.g_h - 1;

            vs_clip( handle, 1, clip );
            if( all )
               vr_recfl( handle, clip );              /* fill rectangle */
            v_gtext( handle, work.g_x, work.g_y + 30, s );
         }
         wind_get( whandle, WF_NEXTXYWH, &box.g_x, &box.g_y, &box.g_w,
                   &box.g_h );
      }
      mouse_on();
   }
}

/* -------------------------------------------------------------------- */
/*    handle_message()                                                  */
/*                                                                      */
/*    Auswertung der Ereignisse des Multi-Events bez�glich des Message- */
/*    buffers.                                                          */
/* -------------------------------------------------------------------- */

int handle_message( int pipe[8] )
{
   switch ( pipe[0] )
   {
      case WM_REDRAW:
         redraw_window(1);
      break;

      case WM_TOPPED:
         wind_set( whandle, WF_TOP );
      break;

      case WM_CLOSED:
         if( pipe[3] == whandle )
         {
            wind_close( whandle );
            wind_delete( whandle );
            whandle = 0;
         }
         if( _app )
            return(1);
      break;

      case WM_MOVED:
      case WM_SIZED:
         if( pipe[3] == whandle )
            wind_set( whandle, WF_CURRXYWH,  pipe[4], pipe[5],
                      pipe[6], pipe[7] );
      break;

      case AC_OPEN:
         if( pipe[4] == menu_id )
            open_window();
      break;

      case AC_CLOSE:
         if( pipe[3] == menu_id )
            whandle = 0;
      break;
   }
   return(0);
}

/* -------------------------------------------------------------------- */
/*    event_loop()                                                      */
/*                                                                      */
/*    Die Multi-Event-Schleife.                                         */
/* -------------------------------------------------------------------- */

static void event_loop( void )
{
   int x, y,
       kstate,
       key,
       clicks,
       event,
       state;
   int pipe[8];
   int quit;

   quit = 0;
   do
   {
      event = evnt_multi( MU_MESAG | MU_TIMER,
                          2, 0x1, 1,
                          0, 0, 0, 0, 0,
                          0, 0, 0, 0, 0,
                          pipe,
                          200, 0,
                          &x, &y, &state, &kstate, &key, &clicks );

      wind_update(BEG_UPDATE);

      if( event & MU_MESAG)
         quit = handle_message( pipe );

      if( event & MU_TIMER)
         redraw_window(0);

      wind_update(END_UPDATE);

   }
   while (!quit);
}

/* -------------------------------------------------------------------- */
/*    main()                                                            */
/*                                                                      */
/*    Kernst�ck des Programms.                                          */
/* -------------------------------------------------------------------- */

int main( void )
{
   int i;
   int work_in[11];
   int work_out[57];

   /* ----------------------------------------------------------------- */
   /* Initialization                                                    */
   /* ----------------------------------------------------------------- */

   appl_id = appl_init();
   if( appl_id != -1 )
   {
      for (i = 0; i < 10; i++)
         work_in[i]  = 1;
         work_in[10] = 2;
         phys_handle = graf_handle( &gl_wchar, &gl_hchar, &gl_wbox,
                                     &gl_hbox );
      handle = phys_handle;
      v_opnvwk( work_in, &handle, work_out );
      if( handle != 0 )
      {
         tt.u = Tgettime();       /* Startzeit des Programms bestimmen. */
         dt.u = Tgetdate();               /* Aktuelles Datum bestimmen. */
         ti_semaphor = clock();
                                        /* Sekunden Startzeit puffern.  */
         ti_buff[0] = tt.p.second2 * 2 + 1;
         ti_buff[1] = tt.p.minute;
         ti_buff[2] = tt.p.hour;

         max_x = work_out[0];
         max_y = work_out[1];
         if( !_app )              /* Falls das Programm als Accessory   */
                                  /* gestartet wurde, hat _app den      */
                                  /* null, sonst eins.                  */

            menu_id = menu_register( appl_id, "  Clock" );
         else
         {
            graf_mouse( 0, (void*)0 );
            open_window();
         }

   /* ----------------------------------------------------------------- */
   /* Event Loop                                                        */
   /* ----------------------------------------------------------------- */

         event_loop();

   /* ----------------------------------------------------------------- */
   /* Deinitialization                                                  */
   /* ----------------------------------------------------------------- */

         v_clsvwk( handle );
      }
      appl_exit();
   }
   return(0);
}

/* -------------------------------------------------------------------- */
/*    End of CLOCK.C                                                    */
/* -------------------------------------------------------------------- */
