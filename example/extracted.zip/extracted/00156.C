/************************************************************************/
/*                                                                      */
/*    Beispielprogramm:                               APPL_TRECORD()    */
/*                                                      APPL_TPLAY()    */
/*                                                                      */
/*    Copyright (c)  Heimsoeth & Borland  1988                          */
/*                                                                      */
/************************************************************************/

/* -------------------------------------------------------------------- */
/*    Include-Files einbinden.                                          */
/* -------------------------------------------------------------------- */

#include <aes.h>

/* -------------------------------------------------------------------- */
/*    Konstantendefinitionen.                                           */
/* -------------------------------------------------------------------- */

#define STARTMES              0
#define EORECORDING           1
#define REPLAYFAST            2
#define REPLAYHURICANE        3
#define GOODBYE               4

#define BUFSIZE               16000

/* -------------------------------------------------------------------- */
/*    Typendefinitionen.                                                */
/* -------------------------------------------------------------------- */

char *Mess[] =
   {
      "[1][Alle im folgenden gemachten|Mausbewegungen werden nun|aufgezeichnet.][Start]",
      "[3][Das war's.|Und nun die Wiedergabe:][Play]",
      "[1][Nun eine etwas schneller|Wiedergabe.][Play]",
      "[1][Zum Schlu�:|Schnell wie der Wind...][Play]",
      "[3][Damit ist das Programm|beendet.][Ende]"
   };

typedef struct recorder
   {
      long     code;
      long     event;
   }
      RECORD;
/* Declarationen ---------------------------------------------------*/

int usage( int message);

/* -------------------------------------------------------------------- */
/*    Globale Variablen.                                                */
/* -------------------------------------------------------------------- */

RECORD Buffer[BUFSIZE];

/* -------------------------------------------------------------------- */
/*    test_fkt()                                          test function */
/*                                                                      */
/*    Funktion, die dem Austesten dient (hier: appl_trecord()).         */
/* -------------------------------------------------------------------- */

void test_fkt()
{
   usage(STARTMES);
   appl_trecord(Buffer, 2000);
   usage(EORECORDING);
   appl_tplay(Buffer, 2000, 5);
   usage(REPLAYFAST);
   appl_tplay(Buffer, 2000, 20);
   usage(REPLAYHURICANE);
   appl_tplay(Buffer, 2000, 100);
   usage(GOODBYE);
}

/* -------------------------------------------------------------------- */
/*    usage()                                                           */
/*                                                                      */
/*    Es wird eine Meldung f�r den Benutzer ausgegeben, auf die er u.U. */
/*    auf unterschiedliche Art reagieren kann. Der Objektindex des      */
/*    Exitobjektes wird zur�ckgegeben.                                  */
/*                                                                      */
/*    int message       Index der Meldung im Feld Mess (s.o.).          */
/* -------------------------------------------------------------------- */

int usage( int message)
{
   return(form_alert(1, *(Mess + message)));
}

/* -------------------------------------------------------------------- */
/*    Ende der Beispielprogramms f�r APPL_TRECORD(), APPL_TPLAY().      */
/* -------------------------------------------------------------------- */
