Readme                                                      08.08.1988
Turbo C f�r Atari                                          Version 1.0
----------------------------------------------------------------------

Sehr geehrter Turbo C Besitzer,

wir haben uns bem�ht das Handbuch soweit wie m�glich fehlerfrei zu ge-
stalten. Aber wir sind nur Menschen, und Irren ist menschlich. Deshalb
k�nnen Sie in dieser Datei nachlesen, wo uns Fehler unterlaufen  sind,
aber auch, was uns an guten Einf�llen und Tips erst  nach  Redaktions-
schlu� erreichte. Lesen Sie bitte  darum  zuerst  diese  Readme-Datei,
falls Sie nach dem Studium des Handbuches noch Fragen  haben  sollten,
oder wenn beim Betreiben von Turbo C Fragen entstehen sollten.  Beste-
hen danach immer noch Unklarheiten, so wenden Sie sich bitte an  Ihren
Softwareh�ndler oder einen Benutzerklub. In dringenden F�llen erhalten
Sie auch �ber die Heimsoeth software Hotline von  Montag  bis  Freitag
zwischen 14.00 Uhr und 17.00 Uhr unter der  Telefonnummer  089/7258001
Hilfe.



� Die Dateien auf den Originaldisketten
  -------------------------------------
  Die Belegung der  Turbo C  Originaldisketten musste ge�ndert werden.
  Es folgt eine �bersicht:

  Diskette 1:
      README       Tips, Hinweise und Errata
      TC.PRG       Integrierte GEM-Entwicklungsumgebung
      TC.CFG       Konfigurationsdatei f�r TC.PRG
      DEFAULT.PRJ  Standard-Projektdatei
      HELLO.C      Das erste Programm
      CLOCKACC.C   Programmbeispiel f�r Accessories
      MCALC        Unterverzeichnis mit Microcalc-Quellen

  Diskette 2:
      INCLUDE      Unterverzeichnis mit Deklarationsdateien
      LIB          Unterverzeichnis mit Bibliotheksdateien
      TCC.PRG      Kommandozeilenversion von Turbo C
      TLINK.PRG    Separater Linker
      TLIB.PRG     Library Manager

  Diskette 3:
      DEMO         Unterverzeichnis mit GEM-Programmbeispielen
      TC.HLP       Datei f�r das Turbo C Help-System


� TLIB: Libarian-Utility
  ----------------------
  Zusammen mit Turbo C  erhalten Sie  ein Programm zur  Verwaltung von
  Bibliotheksdateien (.LIB).  TLIB erm�glicht Ihnen  das Erstellen und
  Ver�ndern  sowohl eigener Libraries  als auch der  mit  Turbo C  ge-
  lieferten Standard-Libraries.  Eine Beschreibung von TLIB finden Sie
  in der Datei TLIB.DOC.


� Turbo C als Anwendung auf C-Dateien
  -----------------------------------
  Nach dem Installieren Ihres Turbo C-Systems k�nnen Sie  Turbo C  als
  Anwendung  anmelden.  Beachten  Sie jedoch, da� Sie  danach  in  der
  Datei DESKTOP.INF in der Zeile,  welche die  Anwendung spezifiziert,
  den vollst�ndigen Pfad, unter dem Turbo C zu finden ist,  nachtragen
  m�ssen.
  Beispiel:
  In DESKTOP.INF finden Sie nach Anmelden der Anwendung und Sichern
  der Arbeit folgende Zeile:

  #G 03 04   \TC.PRG@ *.C@

  Um Turbo C aus jedem Verzeichnis heraus als Anwendung  f�r C-Dateien
  starten zu k�nnen, m�ssen Sie diese Zeile (auf Ihre Bed�rfnisse  ab-
  gestimmt) um den kompletten Zugriffspfad, unter dem Turbo C zu  fin-
  den ist, erg�nzen:

  #G 03 04   C:\TC\TC.PRG@ *.C@

  Danach wird nach einem Doppelklick auf eine Datei  mit Dateierweite-
  rung '.C' automatisch Turbo C gestartet und die betreffende Datei in
  den Editor geladen.
  Einen kleinen Nachteil birgt diese Methode zur Zeit jedoch noch  (in
  sp�teren Versionen aber nicht mehr). Wenn die angeklickte  Datei  in
  einem anderen Verzeichnis als Turbo C selbst steht, m�ssen  Sie  auf
  die Help-Optionen und Ihr Turbo C-Konfigurationsfile verzichten, so-
  fern diese Dateien sich nicht auch zus�tzlich in demselben Verzeich-
  nis befinden wie die C-Datei.
  Selbstverst�ndlich k�nnen Sie Turbo C auch auf Anwendung auf Header-
  und Projektdateien anmelden.


� Turbo C in Verwendung mit TOS-Shells
  ------------------------------------
  Falls Sie Turbo C von einer TOS-Shell aus starten, k�nnen Sie bis zu
  sechs Dateinammen hinter dem  Aufrufbefehl  angeben.  Diese  Dateien
  werden dann von Turbo C in den Editor nachgeladen.
  Leider l��t sich Turbo C nicht von allen Shells  aus  starten,  denn
  einige Shells halten sich beim Starten von GEM-Programmen  nicht  an
  den vorgegebenen Standard.


� Abbrechen des Compilers
  -----------------------
  Im Handbuch nicht  beschrieben  ist  die  M�glichkeit  den  Compiler
  (nicht den Linker!) w�hrend  eines  �bersetzungslaufs  zu  unterbre-
  chen. Die Tastenkombination dazu lautet SHIFT-SHIFT, dh. Sie  m�ssen
  die beiden Shift-Tasten gleichzeitig dr�cken.  Um  einen  versehent-
  lichen  Abbruch r�ckg�ngig zu machen, fragt Sie Turbo C  danach,  ob
  Sie abbrechen oder aber den Compilerlauf fortsetzen wollen.
  Diese Tastenkombination erweist sich als n�tzlich,  falls  Sie  sehr
  viele Dateien mittels einer Projektdatei �bersetzen  lassen  wollen,
  Ihnen aber w�hrend  der Compilierung  einf�llt,  da�  Sie  vergessen
  haben, eine wesentliche �nderung in einer der Dateien anzubringen.


� Tastaturkommandos
  -----------------
  Nach Drucklegung f�r das Handbuch haben sich einige  neue  Tastatur-
  kommandos ergeben bzw. alte sich ge�ndert.
  Folgende Kommandos sind neu:

      CONTROL-L     Anspringen einer danach einzugebenden Zeilennummer
                    im aktiven Fenster. Diese Funktion finden Sie auch
                    im Men� 'Search' unter dem Punkt 'Goto Line...'.

      CONTROL-U     Schlie�en des aktiven Fensters mit  R�ckfrage nach
                    einer �nderung des zugeh�rigen  Textes,  ob dieser
                    vor dem Schlie�en abgespeichert werden soll.

      CONTROL-B     Compileren des C-Quelltextes im  aktiven Fensters.
                    Diese Funktion  kann  nat�rlich  nicht  aufgerufen
                    werden, falls kein Fenster ge�ffnet ist.
                    Entspricht 'Compile '' ' im Men� 'Compile'.

      CONTROL-M     Es werden alle ver�nderten Quelldateien der  aktu-
                    ellen Projektdatei �bersetzt  und  das  zugeh�rige
                    Programm neu gelinkt.
                    Entspricht 'Make '' ' im Men� 'Projekt'.

      CONTROL-K     Wie CONTROL-M, nach dem Linken wird  das  Programm
                    dann noch gestartet.
                    Entspricht 'Run '' ' im Men� 'Projekt'.

      CONTROL-D     Durch diese Tastenkombination wird es m�glich  den
                    Men�punkt 'Execute...' im  Men�  'Compile'  direkt
                    per Tastatur aufzurufen.


� Blockselektierung
  -----------------
  Inzwischen gibt es eine weitere Methode Bl�cke  im  Editor  mit  der
  Maus zu markieren.
  Die neue Alternative besteht darin,  den Cursor an  den  Anfang bzw.
  das Endes des gew�nschten Blockbereichs zu plazieren,  dann  mit dem
  Mauszeiger an das Ende (oder den Anfang) des Bereichs zu  fahren und
  dort bei gedr�ckter 'Shift'-Taste einen  Einfachklick durchzuf�hren.
  Falls sich bei letzterer Methode einer der Begrenzungspunkte  au�er-
  halb des Fensterbereichs befinden sollte, m�ssen Sie darauf  achten,
  da� Sie den Cursor nicht verschieben, wenn Sie den entgegengesetzten
  Randpunkt im Text aufsuchen. Benutzen Sie deshalb nur  die  Fenster-
  elemente, um sich im Text zu bewegen, da diese keine positionierende
  Auswirkungen auf den Cursor haben.
  Eine einzelne Textzeile k�nnen Sie bequem selektieren, indem Sie bei
  gedr�ckter 'Shift'-Taste einen Doppelklick auf die den  Cursor  ent-
  haltende Zeile ausf�hren.


� 'Shift Left'
  ------------
  Die Funktion 'Shift Left' geht nur, wenn  am  Anfang  der markierten
  Zeilen Tabulatoren stehen.


� Autosave
  --------
  Neu installiert wurde eine Autosave-Option  im  Men�titel  'Options'
  unter dem Punkt 'Editor'. Ist diese Option gesetzt,  so  werden  vor
  jedem 'Execute...' und jedem 'Run '' ' alle im Speicher befindlichen
  und ge�nderten Texte automatisch gesichert.


� Projektdateien
  --------------
  In einer Projektdatei f�r die GEM-Version von Turbo C sind alle  Op-
  tionen erlaubt, die auch f�r die Kommandozeilenversion gelten  (vgl.
  Handbuch Anhang B).

  F�r die Warning Levels gilt:
  Level 0:   Keinerlei Warnungen werden ausgegeben.
  Level 1:   Alle im Anhang B mit (ON) gekennzeichneten Warnungen wer-
             den angezeigt.
  Level 2:   S�mtliche Warnungen werden gemeldet.

  Der Warning Level l��t sich lokal, dh. innerhalb  einer Projektdatei
  �ndern. An der  globalen  Defaulteinstellung  (siehe  Men� 'Options'
  Unterpunkt 'Compiler') �ndert sich dadurch jedoch nichts. Angabe von

        -W bzw. -W+    �ndert den Warning Level auf       2
        -W-            �ndert den Warning Level auf       0

  Innerhalb einer Optionsangabe k�nnen auch mehrere Optionen aufgelis-
  tet werden.
  Beispiel:
               .C[-Wvoi -Wzst]
  Hiermit erreichen Sie, da� der  Compiler  Warnungen  ausgibt,  falls
  eine als 'void' deklarierte  Funktion ein Ergebnis liefert und  eine
  Struktur die L�nge Null hat.
  Beachten Sie, da� zwischen den  einzelnen  Elementen  der Auflistung
  Leerzeichen stehen m�ssen.


� Flie�kommazahlen
  ----------------
  Die Flie�kommaroutinen befinden sich in der Bibliothek 'TCFLTLIB.LIB'.
  Falls Sie in Ihrem Programm  Flie�kommazahlen  verwenden,  so mu� in
  der   Projektdatei  die  Angabe  von  'TCFLTLIB.LIB' unbedingt *vor*
  'TCSTDLIB.LIB' erfolgen.

  Wenn Ihr Programm *keine* Flie�komma-Arithmetik ben�tigt, k�nnen Sie
  TCFLTLIB.LIB aus der Projektdatei entfernen. Dies hat zur Folge, da�
  die Integer-Version der Ein-/Ausgaberoutinen (z.B. scanf und printf)
  gelinkt wird,  welche weniger Speicherplatz beanspruchen.  Zudem be-
  schleunigt  sich der  Linkvorgang,  weil weniger  Bibliotheksdateien
  zu durchsuchen sind.

  F�r Systemprogrammierer ist noch interessant, da� Turbo C  Flie�kom-
  mazahlen (float und double) prinzipiell �ber  den  Stack  an  andere
  Funktionen �bergibt. Ist ein Ergebnis eine Flie�kommazahl,  so  wird
  wird diese ebenfalls auf dem Stack �bergeben.


� Ausgaben auf einen Drucker innerhalb eines C-Programms
  ------------------------------------------------------
  Das folgende Programmbeispiel demonstriert, wie Sie innerhalb
  eines C-Programms die parallele Schnittstelle (z.B. einen Drucker)
  ansprechen k�nnen:

        #include        <stdio.h>

        int main()
        {
                FILE * stdprn;

                stdprn = fopen("PRN:","w");
                fprintf(stdprn,"Dieser String wird gedruckt...\n");

                return 0;
        }



� Leerseiten im Handbuch
  ----------------------
  Die Seiten 304 und 305 des Handbuchs sind durch einen Fehler bei der
  Formatierung nicht bedruckt worden.  Ihr Handbuch  ist dennoch voll-
  st�ndig.


� Fehler in der Beschreibung von TLINK
  ------------------------------------
  In Anhang C (S.526,527) wurde bei der Beschreibung der Optionen
  '-O', '-I', '-U' sowie '-S' die Angabe des '='-Zeichens vergessen.
  Richtig mu� es hei�en:
  '-O=Datei[.Ext]', '-I=Datei[.Ext]', '-U=Symbol', '-S=Stackgr��e'.
  In den Beispielen:
  '-O=TEST -S=8192', '-O=PROG.TOS', '-O=PROG.PRG'.
  Derselbe Fehler hat sich auch im Aufruf von TLINK auf Seite 56
  eingeschlichen.


� Fehlende Funktionsbeschreibungen im Handbuch
  --------------------------------------------
  Leider sind im Handbuch nicht Beschreibungen f�r alle  unter Turbo C
  vorhandenen Funktionen  enthalten. Deshalb an dieser Stelle die feh-
  lenden Beschreibungen:


  putch
  --------------------------------------------------------------------
  Name           �put character� -  Ausgabe  eines  Zeichens  auf  dem
                 Bildschirm

  Definition     void putch(int c);

  Prototyp in    ext.h

  Beschreibung   putch gibt ein Zeichen auf das Ger�t console (dh. den
                 Bildschirm) aus.

  Ergebnis       putch liefert kein Ergebnis.


  ecvt
  --------------------------------------------------------------------
  Name           �e-convert� -  konvertiert  eine  Flie�kommazahl   in
                 einen String.

  Definition     char *ecvt (double value, int ndig, int *dec,
                             int *sign);

  Prototyp in    stdlib.h

  Beschreibung   ecvt  konvertiert  value  in  einen  nullterminierten
                 String mit ndig Ziffern und liefert einen  Zeiger  zu
                 diesem String zur�ck. Der String enth�lt  ausschlie�-
                 lich Ziffern: �ber *dec wird die Position  des  Dezi-
                 malpunkts  relativ  zum  Beginn des Strings zur�ckge-
                 liefert (negative Werte bedeuten  hier:  Dezimalpunkt
                 links vom Stringanfang). Wenn value negativ ist, dann
                 setzt ecvt *sign auf einen Wert  ungleich  Null  (f�r
                 positive Werte von value ist *sign == 0). Die Art der
                 Konvertierung  entspricht  im  Prinzip  dem  e-Format
                 von printf.

  Ergebnis       ecvt liefert einen Zeiger zu einem benutzten und sta-
                 tischen String zur�ck.


  matherr
  --------------------------------------------------------------------
  Name           �math error� - vom Programmierer definierbare Routine
                 zur Behandlung von Flie�kommafehlern.

  Definition     int matherr (struct exception *e);

  Prototyp in    math.h

  Beschreibung   Diese Routine wird bei Flie�kommafehlern  automatisch
                 aufgerufen. Die in math.h definierte Routine  liefert
                 bei einem Fehler den Wert 0.
                 matherr kann vom Programierer beliebig ver�ndert wer-
                 den.  Wenn  die  Routine den Fehler korrigieren kann,
                 sollte sie retval  (in der  Struktur  exception) ent-
                 sprechend setzen  und  einen  Wert  ungleich Null als
                 Funktionsergebnis  zur�ckliefern.  Falls  der  Fehler
                 nicht korrigiert werden kann,  mu� ihr  Ergebnis  der
                 Wert 0 sein -  es wird dann eine Fehlermeldung ausge-
                 geben und errno gesetzt.

  Ergebnis       Die mathematische Funktion, durch  deren  Aufruf  der
                 Fehler  verursacht wurde, nimmt den in retval gesetz-
                 ten Wert als Ergebnis an.


  pow10
  --------------------------------------------------------------------
  Name           �power 10� - berechnet die p. Potenz 10, also 10^y.

  Definition     double pow10 (int p);

  Prototyp in    math.h

  Beschreibung   pow10 liefert das Ergebnis der Berechnung 10 ^ y.

  Ergebnis       Falls  sich das Argument nicht innerhalb der zul�ssi-
                 gen  Grenzen  h�lt, werden die folgenden Fehlerbedin-
                 gungen erzeugt:
                 � �berl�ufe: pow10 liefert  HUGE_VAL und setzt  errno
                   auf den Wert ERANGE.


  vrt_cpyfm
  --------------------------------------------------------------------
  Name           �VDI copy raster transparent� -  Rasterbild  kopieren
                 und farblich �ndern.

  Definition     void vrt_cpyfm(int handle, int wr_mode, int *pxarray,
                                MFDB *psrcMFDB, MFDB *pdesMFDB,
                                int *color_index);

  Prototyp in    vdi.h

  Beschreibung   Die VDI-Routine vrt_cpyfm kopiert ein  Rechteck  �hn-
                 lich wie vro_cpyfm (siehe  auch  Beschreibung  dort).
                 Zus�tzlich ist die M�glichkeit  gegeben,  eine  Farbe
                 f�r gesetzte und gel�schte Punkte im Feld color_index
                 anzugeben.

  Ergebnis       Die Funktion liefert kein Ergebnis.

  Querverweis    vro_cpyfm


  form_keybd
  --------------------------------------------------------------------
  Name           �form keyboard� -  Analyse  einer Tastatureingabe in-
                 nerhalb einer Dialogbox.

  Definition     int form_keybd (OBJECT *fo_ktree, int fo_kobject,
                                 int fo_kobnext, int fo_kchar,
                                 int *fo_knxtobject, int *fo_knxtchar );

  Prototyp in    aes.h

  Beschreibung   form_keybd dient dazu innerhalb einer  Dialogbox  mit
                 editierbaren  Feldern,  durch  fo_ktree spezifiziert,
                 auf die  Sondertasten wie 'TAB', 'Cursor up', 'Cursor
                 down' und 'Return' bzw.  'Enter'  zu  reagieren.  Die
                 Nummer des aktuellen Textfeldes wird  in  fo_kobject,
                 der Tastaturcode einer soeben  erfolgten  Eingabe  in
                 fo_kchar. Falls der Tastaturcode zu  einer  der  oben
                 genannten   Sondertasten  geh�rt,  befindet  sich  in
                 fo_knxtobject das neue aktuelle  Editierfeld  und  in
                 fo_knxtchar eine Null, ansonsten der Tastaturcode der
                 gedr�ckten Taste.   In  fo_kobnext  ist der Index des
                 n�chsten editierbaren Feldes zu �bergeben.

  Ergebnis       Falls mit 'Enter' oder 'Return' ein Defaultobjekt se-
                 lektiert wurde, ist das  Ergebnis  eine  Null,  sonst
                 eine Eins.

  Querverweis    form_do, form_button


  form_button
  --------------------------------------------------------------------
  Name           �form button� - Reagieren auf  einen  Mausklick  �ber
                 einem Objektbaum.

  Definiton      int form_button( OBJECT *fo_btree, int fo_bobject,
                                  int fo_bclicks, int *fo_bnxtobj );

  Prototyp in    aes.h

  Beschreibung   Die Funktion form_button  reagiert  auf  einen  Maus-
                 klick, der �ber dem  Objektbaum  fo_btree  ausgef�hrt
                 wurde, dh. der  Status  des  Objekts fo_bobject, �ber
                 dem sich die Maus zum Zeitpunkt  des  Klicks  befand,
                 wird   entsprechend   angepa�t.    Falls   fo_bobject
                 'disabled' war, befindet sich in fo_bnxtobj ein  Wert
                 ungleich Null. In fo_bclicks mu� die Anzahl der Maus-
                 klicks abgelegt sein.  Falls  fo_bobject  ein  Radio-
                 button war, werden alle �brigen Radiobuttons deselek-
                 tiert.

  Ergebnis       Falls fo_bobject ein Exitobjekt  war,  ist  das Funk-
                 tionsergebnis Null, sonst Eins.

  Querverweis    form_do, form_keybd



� Falsche bzw. grob fehlerhafte Funktionsbeschreibungen
  -----------------------------------------------------

  shel_envrn
  --------------------------------------------------------------------
  Name           �shell environment� - ermitteln der Environment-Vari-
                 ablen.

  Definition     int shell_envrn (char **sh_epvalue, char *sh_eparm );

  Prototyp in    aes.h

  Beschreibung   Mit shell_envrn k�nnen die Startadressen der Environ-
                 ment-Variablen ermittelt werden. Dazu wird  ein  Zei-
                 ger, der  den  Variablennamen  enth�lt,  in  sh_eparm
                 �bergeben, beispielsweise ein Zeiger auf "PATH=". Das
                 Ergebnis ist ein Zeiger, der auf das dem Gleichheits-
                 zeichen  folgende  Zeichen  zeigt.  Dieser  wird   in
                 sh_epvalue abgelegt.

  Ergebnis       Die Funktion liefert als Ergebnis immer Eins.

  Querverweis    shel_find


  appl_write
  --------------------------------------------------------------------
  Name           �application write� - sendet eine Mitteilung an  eine
                 andere Applikation.

  Definition     int appl_write (int ap_wid, int ap_wlength,
                                 void *ap_wbuff );

  Prototyp in    aes.h

  Beschreibung   Die AES-Funktion appl_write sendet eine Mitteilung an
                 eine Applikation ap_wid, die in einem Puffer ap_wbuff
                 der L�nge ap_wlength steht.

  Ergebnis       Wenn das Ergebnis 0 ist, dann ist ein  Fehler  aufge-
                 treten, bei allen anderen Werten konnte die  �bertra-
                 gung korrekt durchgef�hrt werden.



� Nicht existierende Funktionen
  -----------------------------
  Die im  Kapitel 9, S.189  des Handbuches  in  der  Beschreibung  von
  'abort' angegebene Funktion '_exit' existiert nicht.  'abort' arbei-
  tet  aber trotzdem einwandfrei.


� Die Strukturen 'div_t' und 'ldiv_t'
  -----------------------------------
  In diesen beiden Strukturen wurden im  Handbuch die  beiden Elemente
  'rem' und 'quot' vertauscht.
  Richtig m��te es hei�en:

         typedef struct
           {
           long quot ;            /* Rest */
           long rem ;             /* Quotient */
           } ldiv_t ;

  bzw.

         typedef struct
           {
           int quot ;            /* Rest */
           int rem ;             /* Quotient (Divisionsergebnis) */
           } div_t ;



� 'printf' und 'scanf'
  --------------------
  printf:
  Das im Kapitel 9, S.250 angegebene und auf S.251 erkl�rte Syntaxdia-
  diagramm ist in dieser Form falsch. Es mu� richtig hei�en:

      % [Flags] [Breite] [.Pr�zision] [h|l|L] Typ

  'L' steht hierbei f�r 'long double'.

  scanf:
  F�r das Syntaxdiagramm  auf  Seite 267  gilt  das  gleiche  wie  f�r
  'printf' (s.o.).
  Zus�tzlich gilt f�r die Angabe von 'Typ' anstatt der auf S.268 abge-
  druckten Tabelle die folgende:

  Typ    Eingabe             Adress-Parameter
  --------------------------------------------------------------------
         numerische Werte
  --------------------------------------------------------------------
  d      dez. Integer        Zeiger auf int (int *arg)
  ld     dez. Integer        Zeiger auf long (long *arg)
  o      okt. Integer        Zeiger auf int (int *arg)
  lo     okt. Integer        Zeiger auf long (long *arg)
  u      dez. Integer        Zeiger auf unsigned int (unsigned *arg)
  lu     dez. Integer        Zeiger auf unsigned long  (unsigned long
                             *arg)
  x      hex. Integer        Zeiger auf unsigned int (unsigned *arg)
  lx     hex. Integer        Zeiger auf unsigned long  (unsigned long
                             *arg)
  e      Flie�komma          Zeiger auf float (float *arg)
  f      Flie�komma          Zeiger auf float (float *arg)
  g      Flie�komma          Zeiger auf float (float *arg)
  le     Flie�komma          Zeiger auf double (double *arg)
  lf     Flie�komma          Zeiger auf double (double *arg)
  lg     Flie�komma          Zeiger auf double (double *arg)
  Le     Flie�komma          Zeiger auf long double (long double *arg)
  Lf     Flie�komma          Zeiger auf long double (long double *arg)
  Lg     Flie�komma          Zeiger auf long double (long double *arg)



� Stringfunktionen
  ----------------
  strchr        (�character�) -  sucht  einen  String nach dem  ersten
                Vorkommen eines bestimmten Zeichens von links ab.


� TOS-Funktionen
  --------------
  Fcreate       Die Funktion liefert als Ergebnis eine  negative Zahl,
                wenn die Datei nicht angelegt werden konnte, ansonsten
                das Dateihandle der neuen Datei.


� VDI-Funktionen
  --------------
  vsc_form      Das Feld pcurform hat folgende Form:
                  Integer     Bedeutung
                     0        x-Koordinate des aktiven Punkts des Cur-
                              sors, 'hot spot'.
                     1        y-Koordinate des hot spots.
                     2        Immer 1.
                     3        Farbindex f�r die Maske.
                     4        Farbindex f�r die Daten.
                   5 - 20     16 Integer-Werte f�r die Maske.
                  21 - 36     16 Integer-Werte f�r die Daten.

  vex_timv      Der Prototyp dieser Funktion wurde im  Handbuch falsch
                abgedruckt, ist im Headerfile VDI.H aber  richtig  de-
                klariert:
                void vex_timv (int handle, long pus_rcode,
                               long *psavecode, int *tim_conv );
                tim_conv  legt  hier  das  Intervall  in Millisekunden
                fest, in dem die  eigene  Interruptroutine  aufgerufen
                werden soll.

  vq_color      Diese Funktion  liefert  als  Ergebnis einen  Integer-
                Wert. Dieser ist gleich -1, falls der  Farbindex nicht
                gesetzt werden kann.

  vr_cpyfm      Diese Funktion hei�t richtig vro_cpyfm.
                Sie ist unter diesem Namen auch in der Headerdatei und
                der Bibliothek vorhanden.

  vst_alignment Der Prototyp dieser Funktion wurde im  Handbuch falsch
                abgedruckt, ist im Headerfile VDI.H aber  richtig  de-
                klariert:
                void vst_alignment (int handle, int hor_in,
                                    int vert_in, int *hor_out,
                                    int *vert_out );


� AES-Funktionen
  --------------
  appl_trecord  Im Modus 'Timer'  wird  die  Anzahl  der verstrichenen
                Zehntelsekunden aufgezeichnet.

  appl_read     Diese Funktion wird normalerweise nur zum Empfang  von
                Mitteilungen  verwendet,  die mehr als 16 Bytes umfas-
                sen.


� '... terminated with resultcode != 0'
  -------------------------------------
  Wenn  Sie ein Programm mittels 'Execute...' oder  'Run '' '  starten
  und nach Beendigung dieses  Programms  die  Meldung  '... terminated
  with resultcode != 0' erscheint,  so ist dies kein  Grund zur  Beun-
  ruhigung. Die  Meldung  besagt  lediglich, da� das Programm nicht mit
  'exit(0)'  verlassen  wurde.
  Manche Programme benutzen die exit()-Funktion als M�glichkeit, an den
  Aufrufer mittels einer Zahl eine Nachricht zu �bergeben.  Es hat sich
  dabei eingeb�rgert, Werte ungleich Null als Fehlercode zur�ckzugeben.
  Viele  Programme terminieren jedoch ohne die exit()-Funktion aufzuru-
  fen, so da� ein zuf�lliger Wert an den Aufrufer geliefert  wird.  Ist
  dieser ungleich Null, so erhalten Sie bewu�te Meldung.


� �bergro�e Felder
  ----------------
  Sollten Sie ein Feld definieren, das gr��er als 32 kByte ist,
  so m�ssen Sie darauf achten, da� Sie den Feldindex als
  long-Wert angeben.
  ACHTUNG: Die Nichtbeachtung dieser Regel f�hrt zu fehlerhaften
  Zugriffen auf Arrays !
  Ob ein Array die kritische Gr��e von 32kByte �berschreitet,
  stellen Sie am einfachsten mithilfe von 'sizeof()' fest
  (z.B.:  printf("size %ld\n", sizeof(array) ); ).


  Beispiel1:
               int  array[32769];
               long index = 12345;
               array[index] = 1;

  Beispiel2:
               double array[5000];
               array[4999L] = 1.23456789;

  Beispiel3:
               double array[70][70];
               array[65L][67L] = 3.1415926;


� Richtige Zeit und richtiges Datum
  ---------------------------------
  Achten Sie peinlichst darauf, da� Sie immer die  richtige  Zeit  und
  das richtige Datum eingestellt haben, denn nur dadurch  ist  gew�hr-
  leistet, da� die Projektverwaltung korrekt arbeitet.

� Accessories
  -----------
  Selbstverst�ndlich k�nnen Sie mit Turbo C auch Accessories erzeugen.
  Ein Accessory ist im Prinzip wie jedes  andere  GEM-Programm  aufge-
  baut, mit dem einzigen Unterschied, da� es eine  Endlosschleife  be-
  sitzt, in der st�ndig gepr�ft wird, ob der  Anwender  das  Accessory
  starten m�chte, bzw. wenn es schon aktiviert wurde, welche  Operati-
  onen auszul�sen sind. Der Aufbau sieht also in etwa so aus:

      <Programminitialisierung>
      do
      {
         <Multi-Event>

         <Auswertung des Ereignisses>
      }
      while(1);

  Mittels der beiden Ereignisse 'AC_OPEN' und 'AC_CLOSE' f�r  das  Er-
  eigniskriterium 'MU_MESAG' (diese Konstanten sind in  AES.H  verein-
  bart) k�nnen Sie feststellen, ob das Accessory in der Men�leiste ak-
  tiviert  bzw. desaktiviert wurde.
  Als Startupcode f�r Accessories k�nnen Sie  wie  �blich  'TCSTART.O'
  verwenden.

  Als ganz besonderes Feature ist es unter Turbo C m�glich  ein Acces-
  sory auch  als normales  Programm laufen zu lassen.  Dazu m�ssen Sie
  jedoch bei der  Programmierung die folgenden Punkte ber�cksichtigen:

  Innerhalb Ihres Programmes mu� eine Abfrage erfolgen, die pr�ft,  ob
  es sich um ein Accessory oder ein normales  Programm  handelt.  Dazu
  m�ssen Sie zu Beginn Ihres Quelltextes folgende Variable als  extern
  deklarieren (sie ist im Modul 'TCSTART.O' definiert):

      extern _app;

  Diese Variable dient innerhalb Ihres  Programms als  Semaphor  (eine
  Variable, die als Schalter  oder  'Verkehrsampel' benutzt wird), der
  Ihnen sagt,  ob  das  Programm momentan als Accessory  (_app hat den
  Wert Null)  oder als normale Applikation (_app ist gleich 1) betrie-
  ben wird.
  Im weiteren m�ssen Sie Ihr Programm nun noch mittels der  Semaphoren
  so abstimmen, da� Sie die Endlosschleife des  Accessories  verlassen
  k�nnen, falls _app gleich Eins ist, beispielsweise

      quit = 0;
      do
      {
         ...
      }
      while( !(quit && _app) );

  Die Variable quit darf in diesem Fall von einem Accessory nie ver�n-
  dert werden, ein normales Programm mu� aber, falls es beendet werden
  soll, quit einen Wert ungleich Null zuweisen.

  Auf Diskette 3 finden Sie im Ordner 'DEMO' ein Beispielprogramm  na-
  mens 'CLOCKACC.C', das dieses Thema noch einmal aufgreift.




Wir hoffen, hiermit alle Unklarheiten und Fehler ausger�umt zu haben.
Viel Spa� mit Turbo C w�nscht Ihnen

                                          Heimsoeth & Borland
