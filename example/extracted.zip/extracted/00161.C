/************************************************************************/
/*                                                                      */
/*    Programmsequenz zum Starten eines GEM-Programms.                  */
/*                                                                      */
/*    Dieser Programmaussschnitt sollte jedem GEM-Programm voranstehen. */
/*    (In den weiteren Beispielen im Handbuch wird dieser Programmteil  */
/*    als gegeben vorausgesetzt).                                       */
/*                                                                      */
/*    Copyright (c)  Heimsoeth & Borland  1988                          */
/*                                                                      */
/************************************************************************/

/* -------------------------------------------------------------------- */
/*    include - Files einbinden.                                        */
/* -------------------------------------------------------------------- */

#include <vdi.h>
#include <aes.h>
#include <stdio.h>
#include <stdlib.h>

/* -------------------------------------------------------------------- */
/*    Typendefinition.                                                  */
/* -------------------------------------------------------------------- */

enum _bool
   {
      FALSE,
      TRUE
   };

typedef enum _bool  boolean;

/* -------------------------------------------------------------------- */
/*    Globale Variablen.                                                */
/* -------------------------------------------------------------------- */

int contrl[12],
    intin[128],
    intout[128],
    ptsin[128],
    ptsout[128];

int work_in[12],
    work_out[57];

int handle,
    phys_handle;

int gl_hchar,
    gl_wchar,
    gl_hbox,
    gl_wbox;

int gl_apid;

/* ------------------------------------------------------------------- */
/*    Funktionsprototypen.                                             */
/* ------------------------------------------------------------------- */

boolean open_vwork(void);
void    close_vwork(void);
void    test_fkt(void);

/* -------------------------------------------------------------------- */
/*    open_vwork()                                                      */
/*                                                                      */
/*    Workstation �ffnen ...                                            */
/* -------------------------------------------------------------------- */

boolean open_vwork()
{
   register int i;

   if((gl_apid = appl_init()) != -1)
   {
      for(i = 1; i < 10; work_in[i++] = 0);
      work_in[10] = 2;
      phys_handle = graf_handle(&gl_wchar, &gl_hchar, &gl_wbox, &gl_hbox);
      work_in[0] = handle = phys_handle;

      v_opnvwk(work_in, &handle, work_out);

      return(TRUE);
   }
   else
      return(FALSE);
}

/* -------------------------------------------------------------------- */
/*    close_vwork()                                                     */
/*                                                                      */
/*    ... und wieder schlie�en.                                         */
/* -------------------------------------------------------------------- */

void close_vwork()
{

   v_clsvwk(handle);

   appl_exit();
}

/* -------------------------------------------------------------------- */
/*    main()                                                            */
/*                                                                      */
/*    Hier steht dann Ihr C-Programm.                                   */
/* -------------------------------------------------------------------- */

int main()
{
   if(open_vwork() == TRUE)
   {

      /* F�gen Sie Ihr Programm hier ein. */

      test_fkt();

      /* -------------------------------- */

      close_vwork();
   }
   else
      printf("Fehler bei der Programminitialisierung!");
   return 0;
}

/* -------------------------------------------------------------------- */
/*    Ende der Programmsequenz.                                         */
/* -------------------------------------------------------------------- */

