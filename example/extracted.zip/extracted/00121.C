@abort
abort - End program immediately
void abort()
@abs
abs - Return the absolute value of an integer
int abs(n) int n;
@access
access - Check if a file can be accessed in a given mode
#include <access.h>
int access(filename, mode) char *filename; int mode;
@acos
acos - Calculate inverse cosine
#include <math.h>
double acos(arg) double arg;
@appl_exit
appl_exit - Exit from an application
#include <aesbind.h>
int appl_exit()
@appl_find
appl_find - Get another application's handle
#include <aesbind.h>
int appl_find(name) char name[9];
@appl_init
appl_init - Initiate an application
#include <aesbind.h>
int appl_init()
@appl_read
appl_read - Read a message from another application
#include <aesbind.h>
int appl_read(handle, length, buffer) int handle, length; char *buffer;
@appl_tplay
appl_tplay - Replay AES activity
#include <aesbind.h>
int appl_tplay(buffer, number, speed) char *buffer; int number, speed;
@appl_trecord
appl_trecord - Record user actions
#include <aesbind.h>
int appl_trecord(buffer, capacity) char *buffer; int capacity;
@appl_write
appl_write - Send a message to another application
#include <aesbind.h>
int appl_write(handle, length, buffer) int handle, length; char *buffer;
@asctime
asctime - Convert time structure to ASCII string
#include <time.h>
char *asctime(tmp) tm *tmp;
@asin
asin - Calculate inverse sine
#include <math.h>
double asin(arg) double arg;
@assert
assert - Check assertion at run time
#include <assert.h>
assert(expression)
@#assert
#assert - Check assertion at compile time
#assert expression
@atan
atan - Calculate inverse tangent
#include <math.h>
double atan(arg) double arg;
@atan2
atan2 - Calculate inverse tangent
double atan2(num, den) double num, den;
@atof
atof - Convert ASCII strings to floating point
double atof(string) char *string;
@atoi
atoi - Convert ASCII strings to integers
int atoi(string) char *string;
@atol
atol - Convert ASCII strings to long integers
long atol(string) char *string;
@Bconin
Bconin - Receive a character
#include <osbind.h>
#include <bios.h>
long Bconin(handle) int handle;
@Bconout
Bconout - Send a character to a peripheral device
#include <osbind.h>
#include <bios.h>
void Bconout(handle, character) int handle, character;
@Bconstat
Bconstat - Return the input status of a peripheral device
#include <osbind.h>
#include <bios.h>
long Bconstat(device) int device;
@Bcostat
Bcostat - Read the output status of a peripheral device
#include <osbind.h>
#include <bios.h>
long Bcostat(handle) int handle;
@bios
bios - Call an input/output routine in the TOS BIOS
#include <osbind.h>
extern long bios(n, f1, f2 ... fn);
@Bioskeys
Bioskeys - Reset the keyboard to its default
#include <osbind.h>
#include <xbios.h>
void Bioskeys()
@Blitmode
Blitmode - Get/set blitter configuration
int Blitmode(flag) int flag;
@cabs
cabs - Complex absolute value function
#include <math.h>
double cabs(z) struct { double r, i; } z;
@calloc
calloc - Allocate dynamic memory
char *calloc(count, size) unsigned count, size;
@Cauxin
Cauxin - Read a character from the serial port
#include <osbind.h>
long Cauxin()
@Cauxis
Cauxis - Check if characters are waiting at serial port
#include <osbind.h>
long Cauxis()
@Cauxos
Cauxos - Check if serial port is ready to receive characters
#include <osbind.h>
long Cauxos()
@Cauxout
Cauxout - Write a char to the serial port
#include <osbind.h>
void Cauxout(c) int c;
@Cconin
Cconin - Read a character from the standard input
#include <osbind.h>
long Cconin()
@Cconis
Cconis - Find if a character is waiting at standard input
#include <osbind.h>
int Cconis()
@Cconos
Cconos - Check if console is ready to receive characters
#include <osbind.h>
long Cconos()
@Cconout
Cconout - Write a character onto standard output
#include <osbind.h>
void Cconout(c) intc;
@Cconrs
Cconrs - Read and edit a string from the standard input
#include <osbind.h>
void Cconrs(string) char *string;
@Cconws
Cconws - Write a string onto standard output
#include <osbind.h>
void Cconws(string) char *string;
@ceil
ceil - Set numeric ceiling
#include <math.h>
double ceil(z) double z;
@clearerr
clearerr - Present stream status
#include <stdio.h>
clearerr(fp) FILE *fp;
@clock
clock - Get number of clock ticks since system boot
#include <time.h>
clock_t clock()
@close
close - Close a file
int close(fd) int fd;
@Cnecin
Cnecin - Perform modified raw input from standard input
#include <osbind.h>
long Cnecin()
@cos
cos - Calculate cosine
#include <math.h>
double cos(radian) double radian;
@cosh
cosh - Calculate hyperbolic cosine
#include <math.h>
double cosh(radian) double radian;
@Cprnos
Cprnos - Check if printer is ready to receive characters
#include <osbind.h>
long Cprnos()
@Cprnout
Cprnout - Send a character to the printer port
#include <osbind.h>
void Cprnout(c) int c;
@Crawcin
Crawcin - Read a raw character from standard input
#include <osbind.h>
long Crawcin()
@Crawio
Crawio - Perform raw I/O with the standard input
#include <osbind.h>
long Crawio(c) int c;
@creat
creat - Create/truncate a file
int creat(file, mode) char *file; int mode;
@ctime
ctime - Convert system time to an ASCII string
#include <time.h>
char *ctime(timep) time_t *timep;
@Cursconf
Cursconf - Get or set the cursor's configuration
#include <osbind.h>
#include <xbios.h>
int Cursconf(function, rate) int function, rate;
@dayspermonth
dayspermonth - Return number of days in a given month
#include <time.h>
int dayspermonth(month, year) int month, year;
@Dcreate
Dcreate - Create a directory
#include <osbind.h>
long Dcreate(path) char *path;
@Ddelete
Ddelete - Delete a directory
#include <osbind.h>
long Ddelete(path) char *path;
@#define
#define - Define a variable as manifest constant
#define constant value
@Dfree
Dfree - Get information on a drive's free space
#include <osbind.h>
void Dfree(fs, drive) long fs[4]; int drive;
@Dgetdrv
Dgetdrv - Find current default disk drive
#include <osbind.h>
int Dgetdrv()
@Dgetpath
Dgetpath - Get the current directory name
#include <osbind.h>
long Dgetpath(buffer, drive) char *buffer; int drive;
@difftime
difftime - Return difference between two times
#include <time.h>
double difftime(newtime, oldtime) time_t newtime, oldtime;
@Dosound
Dosound - Start up the sound daemon
#include <osbind.h>
#include <xbios.h>
long Dosound(buffer) char *buffer;
@Drvmap
Drvmap - Get a map of the logical disk drives
#include <osbind.h>
#include <bios.h>
long Drvmap();
@Dsetdrv
Dsetdrv - Make a drive the current drive
#include <osbind.h>
long Dsetdrv(drive) int drive;
@Dsetpath
Dsetpath - Set the current directory
#include <osbind.h>
long Dsetpath(path) char *path;
@dup
dup - Duplicate a file descriptor
int dup(fd) int fd;
@dup2
dup2 - Duplicate a file descriptor
int dup2(fd, newfd) int fd, newfd;
@ecvt
ecvt - Convert floating-point numbers to strings
char *ecvt(d, prec, dp, signp) double d; int prec, *dp, *signp;
@#elif
#elif - Include code conditionally
#elif (expression)
@#else
#else - Include code conditionally
#else
@#endif
#endif - End conditional inclusion of code
#endif
@errno
errno - External integer for return of error status
extern int errno;
@evnt_button
evnt_button - Await a specific mouse button event
#include <aesbind.h>
int evnt_button(clicks, button, state, xptr, yptr, bptr, kptr)
int clicks, button, state, *xptr, *yptr, *bptr, *kptr;
@evnt_dclick
evnt_dclick - Get/set double-click interval
#include <aesbind.h>
int evnt_dclick(speed, getset) int speed, getset;
@evnt_keybd
evnt_keybd - Await a keyboard event
#include <aesbind.h>
int evnt_keybd()
@evnt_mesag
evnt_mesag - Await a message
#include <aesbind.h>
int evnt_mesag(buffer) int buffer[8];
@evnt_mouse
evnt_mouse - Wait for mouse to enter specified rectangle
#include <aesbind.h>
int evnt_mouse(inout, x, y, w, h, xptr, yptr, bptr, kptr)
int inout, x, y, w, h, *xptr, *yptr, *bptr, *kptr;
@evnt_multi
evnt_multi - Await one or more specified events
#include <aesbind.h>
int evnt_multi(events, clicks, button, state, m1inout, x1, y1, w1, h1,
	m2inout, x2, y2, w2, h2, buffer, lowtime, hightime, xptr, yptr, bptr,
	kptr, key, times)
int events, clicks, button, state, m1inout, x1, y1, w1, h1;
int m2inout, x2, y2, w2, h2, buffer[8], lowtime, hightime;
int *key, *times, *xptr, *yptr, *bptr, *kptr;
@evnt_timer
evnt_timer - Wait for a specified length of time
#include <aesbind.h>
int evnt_timer(lowtime, hightime) int lowtime, hightime;
@execve
execve - Execute a command from within a program
int execve(file, argv, env)
char *file, *argv[], *env[]
@exit
exit - Terminate a program
void exit(status) int status;
@_exit
_exit - Terminate a program
int _exit(status) int status;
@exp
exp - Compute exponent
#include <math.h>
double exp(z) double z;
@fabs
fabs - Compute absolute value
#include <math.h>
double fabs(z) double z;
@Fattrib
Fattrib - Get and set file attributes
#include <osbind.h>
long Fattrib(name, readset, setatrib) char *name;
int readset, setatrib;
@Fclose
Fclose - Close a file
#include <osbind.h>
long Fclose(handle) int handle;
@fclose
fclose - Close stream
#include <stdio.h>
int fclose(fp) FILE *fp;
@Fcreate
Fcreate - Create a file
#include <osbind.h>
long Fcreate(name, type) char *name; int type;
@fcvt
fcvt - Convert floating point numbers to ASCII strings
char *fcvt(d, w, dp, signp) double d; int w, *dp, *signp;
@Fdatime
Fdatime - Get or set a file's date/time stamp
#include <osbind.h>
long Fdatime(info, handle, getset)
int handle, getset, info[2];
@Fdelete
Fdelete - Delete a file
#include <osbind.h>
long Fdelete(name) char *name;
@fdopen
fdopen - Open a stream for standard I/O
#include <stdio.h>
FILE *fdopen(fd, type) int fd; char *type;
@Fdup
Fdup - Generate a substitute file handle
#include <osbind.h>
long Fdup(handle) int handle;
@feof
feof - Discover stream status
#include <stdio.h>
int feof(fp) FILE *fp;
@ferror
ferror - Discover stream status
#include <stdio.h>
int ferror(fp) FILE *fp;
@fflush
fflush - Flush output stream's buffer
#include <stdio.h>
int fflush(fp) FILE *fp;
@Fforce
Fforce - Force a file handle
#include <osbind.h>
long Fforce(shandle, nshandle) int shandle, nshandle;
@fgetc
fgetc - Read character from stream
#include <stdio.h>
int fgetc(fp) FILE *fp;
@Fgetdta
Fgetdta - Get a disk transfer address
#include <osbind.h>
#include <stat.h>
(DMABUFFER *)Fgetdta()
@fgets
fgets - Read line from stream
#include <stdio.h>
char *fgets(s, n, fp) char *s; int n; FILE *fp;
@fgetw
fgetw - Read integer from stream
#include <stdio.h>
int fgetw(fp) FILE *fp;
@fileno
fileno - Get file descriptor
#include <stdio.h>
int fileno(fp) FILE *fp;
@floor
floor - Set a numeric floor
#include <math.h>
double floor(z) double z;
@Flopfmt
Flopfmt - Format tracks on a floppy disk
#include <osbind.h>
#include <xbios.h>
int Flopfmt(buffer, intbuf, device, sectors, track, side,
	interleave, magic, new)
char *buffer;
int *intbuf, device, sectors, track, side, interleave, new;
long magic;
@Floprd
Floprd - Read sectors on a floppy disk
#include <osbind.h>
#include <xbios.h>
int Floprd(buffer, filler, device, sector, track, side, count)
char *buffer, *filler; int device, sector, track, side, count;
@Flopver
Flopver - Verify a floppy disk
#include <osbind.h>
#include <xbios.h>
int Flopver(buffer, filler, device, sector, track, side, count)
char *buffer, *filler; int device, sector, track, side, count;
@Flopwr
Flopwr - Write sectors on a floppy disk
#include <osbind.h>
#include <xbios.h>
int Flopwr(buffer, filler, device, sector, track, side, count)
char *buffer, *filler; int device, sector, track, side, count;
@Fopen
Fopen - Open a file
#include <osbind.h>
long Fopen(name, mode) char *name; int mode;
@fopen
fopen - Open a stream for standard I/O
#include <stdio.h>
FILE *fopen (name, type) char *name, *type;
@form_alert
form_alert - exit button
Display an alert box
#include <aesbind.h>
int form_alert(button, string) int button; char *string;
@form_center
form_center - Center an object on the screen
#include <aesbind.h>
#include <obdefs.h>
int form_center( picture, xptr, yptr, wptr, hptr)
OBJECT *picture; int *xptr, *yptr, *wptr, *hptr;
@form_dial
form_dial - Reserve/free screen space for dialogue
#include <aesbind.h>
int form_dial(flag, openx, openy, openw, openh, endx, endy, endw, endh)
int flag, openx, openy, openw, openh, endx, endy, endw, endh;
@form_do
form_do - Handle user input in form dialogue
#include <aesbind.h>
int form_do(tree, object) OBJECT *tree; int object;
@form_error
form_error - Display an  error
#include <aesbind.h>
int form_error(error) int error;
@fprintf
fprintf - Print formatted output onto file stream
int fprintf(fp, format,[arg1, . . . . argN])
FILE *fp; char *format;
[data type] arg1, . . . argN;
@fputc
fputc - Write character onto file stream
#include <stdio.h>
int fputc(c, fp) char c; FILE *fp;
@fputs
fputs - Write string to file stream
#include <stdio.h>
fputs(string, fp) char *string; FILE *fp;
@fputw
fputw - Write an integer to a stream
#include <stdio.h>
int fputw(word, fp) int word; FILE *fp;
@fread
fread - Read data from file stream
#include <stdio.h>
int fread(buffer, size, n, fp)
char *buffer; unsigned size, n; FILE *fp;
@Fread
Fread - Read a file
#include <osbind.h>
long Fread(handle, n, buffer)
int handle; long n; char *buffer;
@free
free - Return dynamic memory to free memory pool
void free(ptr) char *ptr;
@Frename
Frename - Rename a file
#include <osbind.h>
long Frename(n, oldpath, newpath) int n;
char *oldpath, newpath;
@freopen
freopen - Open file stream for standard I/O
#include <stdio.h>
FILE *freopen (name, type, fp)
char *name, *type; FILE *fp;
@frexp
frexp - Separate fraction and exponent
double frexp(real, ep) double real; int *ep;
@fscanf
fscanf - Format input from a file stream
#include <stdio.h>
int fscanf(fp, format, arg1, . . . argN)
FILE *fp; char *format;
[data type] *arg1, . . . *argN;
@fseek
fseek - Seek on file stream
#include <stdio.h>
int fseek(fp, where, how)
FILE *fp; long where; int how;
@Fseek
Fseek - Move a file pointer
#include <osbind.h>
long Fseek(n, handle, mode) long n; int handle, mode;
@fsel_input
fsel_input - Select a file
#include <aesbind.h>
int fsel_input(directory, file, button) char *directory, *file; int *button;
@Fsetdta
Fsetdta - Set disk transfer address
#include <osbind.h>
#include <stat.h>
void Fsetdta(c) DMABUFFER *c;
@Fsfirst
Fsfirst - Search for first occurrence of a file
#include <osbind.h>
#include <stat.h>
int Fsfirst(name, attrib) char *name; int attrib;
@Fsnext
Fsnext - Search for next occurrence of file name
#include <osbind.h>
#include <stat.h>
int Fsnext()
@fstat
fstat - Find file attributes
#include <stat.h>
fstat(descriptor, statptr) int descriptor; struct stat *statptr;
@ftell
ftell - Return current position of file pointer
#include <stdio.h>
long ftell(fp) FILE *fp;
@function
function - @fwrite
fwrite - Write onto file stream
#include <stdio.h>
int fwrite(buffer, size, n, fp)
char *buffer; unsigned size, n; FILE *fp;
@Fwrite
Fwrite - Write into a file
#include <osbind.h>
long Fwrite(handle, n, buffer) int handle; long n; char *buffer;
@gcvt
gcvt - Convert floating point number to ASCII string
char *gcvt(d, prec, buffer)
double d; int prec; char *buffer;
@gemdos
gemdos - Call a routine from GEM-DOS
#include <osbind.h>
extern long gemdos(n, arg1 ... argn);
@Getbpb
Getbpb - Get pointer to BIOS parameter block for a disk drive
#include <osbind.h>
#include <bios.h>
(struct bpb *)Getbpb(device);
int device;
@getc
getc - Read character from file stream
#include <stdio.h>
int getc(fp) FILE *fp;
@getchar
getchar - Read character from standard input
#include <stdio.h>
int getchar()
@getenv
getenv - Read environmental variable
char *getenv(VARIABLE) char *VARIABLE;
@Getmpb
Getmpb - Copy memory parameter block
#include <osbind.h>
#include <bios.h>
void Getmpb(pointer); struct mpb *pointer;
@Getrez
Getrez - Read the current screen resolution
#include <osbind.h>
#include <xbios.h>
int Getrez()
@gets
gets - Read string from standard input
#include <stdio.h>
char *gets(buffer) char *buffer;
@Getshift
Getshift - Get or set the status flag for shift/alt/control keys
#include <osbind.h>
#include <bios.h>
long Getshift(flag) int flag;
@Gettime
Gettime - Read the current time
#include <osbind.h>
#include <xbios.h>
long Gettime()
@getw
getw - Read word from file stream
#include <stdio.h>
int getw(fp) FILE *fp;
@Giaccess
Giaccess - Access a register on the GI sound chip
#include <osbind.h>
#include <xbios.h>
char Giaccess(data, register) char data; int register;
@gmtime
gmtime - Convert system time to calendar structure
#include <time.h>
tm *gmtime(timep) time_t *timep;
@graf_dragbox
graf_dragbox - Draw a dragable box
#include <aesbind.h>
int graf_dragbox(width, height, stx, sty, bx, by, bw, bh, finx, finy)
int width, height, stx, sty, bx, by, bw, bh, *finx, *finy;
@graf_growbox
graf_growbox - Draw a growing box
#include <aesbind.h>
int graf_growbox(stx, sty, stw, sth, finx, finy, finw, finh)
int stx, sty, stw, sth, finx, finy, finw, finh;
@graf_handle
graf_handle - Get a VDI handle
#include <aesbind.h>
int graf_handle(chwidth, chheight, bwidth, bheight)
int *chwidth, *chheight, *bwidth, *bheight;
@graf_mbox
graf_mbox - Move a box
#include <aesbind.h>
int graf_mbox(width, height, fromx, fromy, tox, toy)
int width, height, fromx, fromy, tox, toy;
@graf_mkstate
graf_mkstate - Get the current mouse state
#include <aesbind.h>
int graf_mkstate(xptr, yptr, bptr, kptr) int *xptr, *yptr, *bptr, *kptr;
@graf_mouse
graf_mouse - Change the shape of the mouse pointer
#include <aesbind.h>
int graf_mouse(form, shape) int form; int shape[37];
@graf_rubbox
graf_rubbox - graf_rubberbox
Draw a rubber box
#include <aesbind.h>
int graf_rubbox(x, y, w, h, newwidth, newheight)
int x, y, w, h, *newwidth, *newheight;
@graf_shrinkbox
graf_shrinkbox - Draw a shrinking box
#include <aesbind.h>
int graf_shrinkbox(beginx, beginy, beginw, beginh, endx, endy, endw, endh)
int beginx, beginy, beginw, beginh, endx, endy, endw, endh;
@graf_slidebox
graf_slidebox - Track the slider within a box
#include <aesbind.h>
#include <obdefs.h>
int graf_slidebox(tree, parent, slider, direction)
char *tree; int parent, slider, direction;
@graf_watchbox
graf_watchbox - Draw a watched box
#include <aesbind.h>
#include <obdefs.h>
int graf_watchbox(tree, object, insidepattern, outsidepattern)
OBJECT *tree; int object, insidepattern, outsidepattern;
@hypot
hypot - Compute hypotenuse of right triangle
#include <math.h>
double hypot(x, y) double x, y;
@#if
#if - Include code conditionally
#if (expression)
@#ifdef
#ifdef - Include code conditionally
#ifdef identifier
@#ifndef
#ifndef - Include code conditionally
#ifndef identifier
@Ikbdws
Ikbdws - Write a string to the intelligent keyboard device
#include <osbind.h>
#include <xbios.h>
void Ikbdws(number, buffer) int number; char *buffer;
@#include
#include - Copy a header file into a program
#include <file.h>
#include file.h
@index
index - Find a character in a string
char *index(string, c) char *string; char c;
@Initmous
Initmous - Initialize the mouse
#include <osbind.h>
#include <xbios.h>
void Initmous(type, parameter, vector)
int type; char *parameter; long vector;
@Iorec
Iorec - Set the I/O record
#include <osbind.h>
#include <xbios.h>
iorec *Iorec(device) int device;
@isalnum
isalnum - Check if a character is a number or letter
#include <ctype.h>
int isalnum(c) int c;
@isalpha
isalpha - Check if a character is a letter
#include <ctype.h>
int isalpha(c) int c;
@isascii
isascii - Check if a character is an ASCII character
#include <ctype.h>
int isascii(c) int c;
@iscntrl
iscntrl - Check if a character is a control character
#include <ctype.h>
int iscntrl(c) int c;
@isdigit
isdigit - Check if a character is a numeral
#include <ctype.h>
int isdigit(c) int c;
@isleapyear
isleapyear - Indicate if a year was a leap year
#include <time.h>
int isleapyear(year) int year;
@islower
islower - Check if a character is a lower-case letter
#include <ctype.h>
int islower(c) int c;
@isprint
isprint - Check if a character is printable
#include <ctype.h>
int isprint(c) int c;
@ispunct
ispunct - Check if a character is a punctuation mark
#include <ctype.h>
int ispunct(c) int c;
@isspace
isspace - Check if a character prints white space
#include <ctype.h>
int isspace(c) int c;
@isupper
isupper - Check if a character is an upper-case letter
#include <ctype.h>
int isupper(c) int c;
@j0
j0 - Compute Bessel function
#include <math.h>
double j0(z) double z;
@j1
j1 - Compute Bessel function
#include <math.h>
double j1(z) double z;
@jday_to_time
jday_to_time - Convert Julian date to system time
#include <time.h>
time_t jday_to_time(time) jday_t time;
@jday_to_tm
jday_to_tm - Convert Julian date to system calendar format
#include <time.h>
tm_t *jday_to_tm(time) jday_t time;
@Jdisint
Jdisint - Disable interrupt on muli-function peripheral device
#include <osbind.h>
#include <xbios.h>
void Jdisint(number) int number;
@Jenabint
Jenabint - Enable a multi-function peripheral port interrupt
#include <osbind.h>
#include <xbios.h>
void Jenabint(number) int number;
@jn
jn - Compute Bessel function
#include <math.h>
double jn(n, z) int n; double z;
@Kbdvbase
Kbdvbase - Return a pointer to the keyboard vectors
#include <osbind.h>
#include <xbios.h>
kbdvbase *Kbdvbase()
@Kbrate
Kbrate - Get or set the keyboard's repeat rate
#include <osbind.h>
#include <xbios.h>
int Kbrate(start, delay) int start, delay;
@Keytbl
Keytbl - Set the keyboard's translation table
#include <osbind.h>
#include <xbios.h>
keytbl *Keytbl(unshifted, shifted, caplock) char *unshifted, *shifted, *caplock;
@Kgettime
Kgettime - Read time from intelligent keyboard's clock
#include <time.h>
tm *Kgettime();
@Ksettime
Ksettime - Set time in intelligent keyboard's clock
#include <time.h>
int Ksettime(time) tm *time;
@lcalloc
lcalloc - Allocate dynamic memory
char *lcalloc(count, size)
unsigned long count, size;
@ldexp
ldexp - Combine fraction and exponent
double ldexp(f, e) double f; int e;
@#line
#line - Reset line numbering
#line number
#line number filename
#line manifest constants
@lmalloc
lmalloc - Allocate dynamic memory
char *lmalloc(size) unsigned long size;
@localtime
localtime - Convert system time to calendar structure
#include <time.h>
tm *localtime(timep) time_t *timep;
@log
log - Compute natural logarithm
#include <math.h>
double log(z) double z;
@log10
log10 - Compute common logarithm
#include <math.h>
double log10(z) double z;
@Logbase
Logbase - Read the logical screen's display base
#include <osbind.h>
#include <xbios.h>
char *Logbase()
@longjmp
longjmp - Return from a non-local goto
#include <setjmp.h>
int longjmp(env, rval) jmp_buf env; int rval
@lrealloc
lrealloc - Reallocate dynamic memory
char *lrealloc(ptr, size)
char *ptr; unsigned long size;
@lseek
lseek - Set read/write position
long lseek(fd, where, how)
int fd, how; long where;
@Malloc
Malloc - Allocate dynamic memory
#include <osbind.h>
long Malloc(n) long n;
@malloc
malloc - Allocate dynamic memory
char *malloc(size) unsigned size;
@Mediach
Mediach - Check whether disk has been changed
#include <osbind.h>
#include <bios.h>
long Mediach(drive) int drive;
@memchr
memchr - Search a region of memory for a character
char *memchr(region, character, n)
char *region;
unsigned int character, n;  
@memcmp
memcmp - Compare two regions
int memcmp(region1, region2, count)
char *region1, *region2;
unsigned int count;  
@memcpy
memcpy - Copy one region of memory into another
char *memcpy(region1, region2, n)
char *region1, *region2;
unsigned int n;  
@memset
memset - Fill an area with a character
char *memset(buffer, character, n);
char *buffer; int character; unsigned int n;  
@menu_bar
menu_bar - Show or erase the menu bar
#include <aesbind.h>
#include <obdefs.h>
int menu_bar(tree, eraseshow) OBJECT *tree; int eraseshow;
@menu_icheck
menu_icheck - Write or erase a check mark next to a menu item
#include <aesbind.h>
#include <obdefs.h>
int menu_icheck(tree, item, eraseshow) OBJECT *tree; int item, eraseshow;
@menu_ienable
menu_ienable - Enable or disable a menu item
#include <aesbind.h>
#include <obdefs.h>
int menu_ienable(tree, object, disable)
OBJECT *tree; int object, disable;
@menu_register
menu_register - Add a name to the desk accessory menu list
#include <aesbind.h>
#include <obdefs.h>
int menu_register(accessory, textstring) int accessory; char *textstring;
@menu_text
menu_text - Replace text of a menu item
#include <aesbind.h>
#include <obdefs.h>
int menu_text(tree, object, text) OBJECT *tree; char *text; int object;
@menu_tnormal
menu_tnormal - Display menu title in normal or reverse video
#include <aesbind.h>
#include <obdefs.h>
int menu_tnormal(tree, object, video) OBJECT *tree; int object, video;
@Mfpint
Mfpint - Initialize the MFP interrupt
#include <osbind.h>
#include <xbios.h>
void Mfpint(interrupt, vector) int interrupt; char *vector;
@Mfree
Mfree - Free allocated memory
#include <osbind.h>
long Mfree(memory) long memory;
@Midiws
Midiws - Write a string to the MIDI port
#include <osbind.h>
#include <xbios.h>
void Midiws(count, pointer) int count; char *pointer;
@mktemp
mktemp - Generate a temporary file name
char *mktemp(pattern) char *pattern;
@modf
modf - Separate integral part and fraction
double modf(real, ip) double real, *ip;
@Mshrink
Mshrink - Shrink amount of allocated memory
#include <osbind.h>
long Mshrink(begin, length) int n; long begin, length;
@notmem
notmem - Check if memory is allocated
int notmem(ptr) char *ptr;
@objc_add
objc_add - Redefine a child object within an object tree
#include <aesbind.h>
#include <obdefs.h>
int objc_add(tree, parent, child) OBJECT *tree; int parent, child;
@objc_change
objc_change - Change object's state
#include <aesbind.h>
#include <obdefs.h>
int objc_change(tree, object, junk, x, y, w, h, newstate, redraw)
OBJECT *tree; int object, junk, x, y, w, h, newstate, redraw;
@objc_delete
objc_delete - Delete an object from an object tree
#include <aesbind.h>
#include <obdefs.h>
int objc_delete(tree, object) OBJECT *tree; int object;
@objc_draw
objc_draw - Draw an object
#include <aesbind.h>
#include <obdefs.h>
int objc_draw(tree, object, depth, x, y, w, h)
OBJECT *tree; int object, depth, x, y, w, h;
@objc_edit
objc_edit - Edit a text object
#include <aesbind.h>
#include <obdefs.h>
int objc_edit(tree, object, character, oldindex, kind, newindex)
OBJECT *tree; int object, character, oldindex, kind, *newindex;
@objc_find
objc_find - Find if mouse pointer is over particular object
#include <aesbind.h>
#include <obdefs.h>
int objc_find(tree, object, depth, mousex, mousey)
OBJECT *tree; int object, depth, mousex, mousey;
@objc_offset
objc_offset - Calculate an object's absolute screen position
#include <aesbind.h>
int objc_offset(tree, object, x, y)
OBJECT *tree; int object, *x, *y;
@objc_order
objc_order - Reorder a child object within the object tree
#include <aesbind.h>
#include <obdefs.h>
int objc_order(tree, object, newposition)
OBJECT *tree; int object, newposition;
@Offgibit
Offgibit - Clear a bit in the sound chip's A port
#include <osbind.h>
#include <xbios.h>
void Offgibit(mask) char mask;
@Ongibit
Ongibit - Turn on a bit in the sound chip's A port
#include <osbind.h>
#include <xbios.h>
void Ongibit(mask) char mask;
@open
open - Open a file
int open(file, type) char *file; int type;
@path
path - Build a path name for a file
#include <path.h>
#include <stdio.h>
char *path(path, filename, mode) char *path, *filename; int mode;
@peekb
peekb - Extract a byte from memory
int peekb(bp) char *bp;
@peekl
peekl - Extract a long from memory
long peekl(lp) long *lp;
@peekw
peekw - Extract a word from memory
int peekw(wp) int *wp;
@perror
perror - System call error messages
#include <errno.h>
perror(string)
char *string; extern int sys_nerr; extern char *sys_errlist[];
@Pexec
Pexec - Load or execute a process
#include <osbind.h>
long Pexec(mode, path, tail, env)
int mode ; char *path, *tail, *env;
@Physbase
Physbase - Read the physical screen's display base
#include <osbind.h>
#include <xbios.h>
char *Physbase()
@pnmatch
pnmatch - Match string pattern
int pnmatch(string, pattern, flag)
char *string, *pattern; int flag;
@pokeb
pokeb - Insert a byte into memory
int pokeb(bp, b) char *bp; int b;
@pokel
pokel - Insert a long into memory
long pokel(lp, l) long *lp, l;
@pokew
pokew - Insert a long into memory
int pokew(wp, l) int *wp, w;
@pow
pow - Compute a power of a number
#include <math.h>
double pow(z, x) double z, x;
@printf
printf - Format output
int printf(format,[arg1, . . . . argN ])
char *format;[data type] arg1, . . . argN;
@Protobt
Protobt - Generate a prototype boot sector
#include <osbind.h>
#include <xbios.h>
void Protobt(buffer, serialno, type, flag)
char *buffer; long serialno; int type, flag;
@Prtblk
Prtblk - Print a dump of the screen
#include <osbind.h>
#include <xbios.h>
int Prtblk(p) struct prtblk *p;
@Pterm
Pterm - Terminate a process
#include <osbind.h>
void Pterm(status) int status;
@Pterm0
Pterm0 - Terminate an  process
#include <osbind.h>
void Pterm0()
@Ptermres
Ptermres - Terminate a process but keep it in memory
#include <osbind.h>
void Ptermres(n, code) long n; int code;
@Puntaes
Puntaes - Disable AES
#include <osbind.h.h>
#include <xbios.h>
void Puntaes()
@putc
putc - Write character to stream
#include <stdio.h>
int putc(c, fp) char c; FILE *fp;
@putchar
putchar - Write a character to standard output
#include <stdio.h>
int putchar(c) char c;
@puts
puts - Write string to standard output
#include <stdio.h>
void puts(string) char *string
@putw
putw - Write word to stream
#include <stdio.h>
int putw(word, fp) int word; FILE *fp;
@qsort
qsort - Sort arrays in memory
void qsort(data, n, size, comp) char *data; int n, size; int (*comp)();
@rand
rand - Generate pseudo-random numbers
int rand()
@Random
Random - Generate a 24-bit pseudo-random number
#include <osbind.h>
#include <xbios.h>
long Random()
@rc_copy
rc_copy - Copy a rectangle
#include <aesbind.h>
int rc_copy(oldrect, newrect) int oldrect[4], newrect[4];
@rc_equal
rc_equal - Compare two rectangles
#include <aesbind.h>
int rc_equal(rect1, rect2) int rect1[4], rect2[4];
@rc_intersect
rc_intersect - Check if two rectangles intersect
#include <aesbind.h>
int rc_intersect(rect1, rect2) int rect1[4], rect2[4];
@rc_union
rc_union - Calculate overlap between two rectangles
#include <aesbind.h>
void rc_union(rect1, rect2) int rect1[4], rect2[4];
@read
read - Read from a file
int read(fd, buffer, n) int fd; char *buffer; int n;
@realloc
realloc - Reallocate dynamic memory
char *realloc(ptr, size) char *ptr; unsigned size;
@rewind
rewind - Reset file pointer
#include <stdio.h>
int rewind(fp) FILE *fp;
@rindex
rindex - Find a character in a string
char *rindex(string, c) char *string; char c;
@Rsconf
Rsconf - Configure the serial port
#include <osbind.h>
#include <xbios.h>
long Rsconf(speed, flow, UCR, RSR, TSR, SCR)
int speed, flow, UCR, RSR, TSR, SCR;
@rsrc_free
rsrc_free - Free memory allocated to a set of resources
#include <aesbind.h>
int rsrc_free()
@rsrc_gaddr
rsrc_gaddr - Get the address of a resource object
#include <aesbind.h>
int rsrc_gaddr(type, index, address) int type, index; OBJECT **address;
@rsrc_load
rsrc_load - Load a resource file into memory
#include <aesbind.h>
int rsrc_load(filename) char *filename;
@rsrc_obfix
rsrc_obfix - Change the form of an object's coordinates
#include <aesbind.h>
#include <obdefs.h>
int rsrc_obfix(tree, object) char *tree; int object;
@rsrc_saddr
rsrc_saddr - Store address of a free string or a bit image
#include <aesbind.h>
int rsrc_saddr(type, index, address) int type, index; char *address;
@Rwabs
Rwabs - Read or write data on a disk drive
#include <osbind.h>
#include <bios.h>
long Rwabs(r_or_w, buffer, n, rec, drive) int r_or_w, n, rec, drive; char *buffer;
@sbrk
sbrk - Increase a program's data space
char *sbrk(increment)
unsigned int increment;
@scanf
scanf - Accept and format input
#include <stdio.h>
int scanf(format, arg1, . . . argN)
char *format;[data type] *arg1, . . . *argN;
@Scrdmp
Scrdmp - Print a dump of the screen
#include <osbind.h>
#include <xbios.h>
void Scrdmp()
@scrp_read
scrp_read - Read the scrap directory
#include <aesbind.h>
int scrp_read(buffer) char *buffer;
@scrp_write
scrp_write - Write to the scrap directory
#include <aesbind.h>
int scrp_write(directory) char *directory;
@setbuf
setbuf - Set alternative stream buffers
#include <stdio.h>
setbuf(fp, buffer) FILE *fp; char *buffer;
@Setcolor
Setcolor - Set one color
#include <osbind.h>
#include <xbios.h>
int Setcolor(number, value) int number, value;
@Setexc
Setexc - Get or set an exception vector
#include <osbind.h>
#include <bios.h>
long Setexc(number, address) int number; char *address;
@setjmp
setjmp - Perform non-local goto
#include <setjmp.h>
int setjmp(env) jmp_buf env;
@Setpallete
Setpallete - Set the screen's color palette
#include <osbind.h>
#include <xbios.h>
void Setpallete(palette) int palette[16];
@Setprt
Setprt - Get or set the printer's configuration
#include <osbind.h>
#include <xbios.h>
int Setprt(configuration) int configuration;
@Setscreen
Setscreen - Set the video parameters
#include <osbind.h>
#include <xbios.h>
void Setscreen(log, phys, res) char *log, *phys; int res;
@Settime
Settime - Set the current time
#include <osbind.h>
#include <xbios.h>
void Settime(datetime) long datetime;
@shel_envrn
shel_envrn - Search for an environmental variable
#include <aesbind.h>
int shel_envrn(parameter, name) char *parameter, *name;
@shel_find
shel_find - Search PATH for file name
#include <aesbind.h>
int shel_find(pathname) char *pathname;
@shel_read
shel_read - Let an application identify the program that called it
#include <aesbind.h>
int shel_read(command, tail) char *command, *tail;
@shel_write
shel_write - Run another application
#include <aesbind.h>
int shel_write(flag, graphic, gem, command, tail)
int flag, graphic, gem; char *command, *tail;
@shellsort
shellsort - Sort arrays in memory
void shellsort(data, n, size, comp)
char *data; int n, size; int (*comp)();
@sin
sin - Calculate sine
#include <math.h>
double sin(radian) double radian;
@sinh
sinh - Calculate hyperbolic sine
#include <math.h>
double sinh(radian) double radian;
@sprintf
sprintf - Format output
#include <stdio.h>
int sprintf(string, format[, arg ] . . .)
char *string, *format;
@sqrt
sqrt - Compute square root
#include <math.h>
double sqrt(z) double z;
@srand
srand - Seed random number generator
void srand(seed) int seed;
@sscanf
sscanf - Format input
#include <stdio.h>
int sscanf(string, format[, arg ] . . .)
char *string; char *format;
@stat
stat - Find file attributes
#include <stat.h>
int stat(file, statptr)
char *file; struct stat *statptr;
@stime
stime - Set the operating system time
.B #include <time.h>
int stime(timep) time_t *timep;
@strcat
strcat - Append one string to another
char *strcat(string1, string2) char *string1, *string2;
@strcmp
strcmp - Compare two strings
int strcmp(string1, string2) char *string1, *string2;
@strcpy
strcpy - Copy one string into another
char *strcpy(string1, string2) char *string1, *string2;
@strcspn
strcspn - Return length for which one string excludes characters in another
unsigned int strcspn(string1, string2)
char *string1, *string2;  
@strlen
strlen - Measure the length of a string
int strlen(string) char *string;
@strncat
strncat - Append one string onto another
char *strncat(string1, string2, n)
char *string1, *string2; unsigned n;
@strncmp
strncmp - Compare two strings
int strncmp(string1, string2, n)
char *string1, *string2; unsigned n;
@strncpy
strncpy - Copy one string into another
char *strncpy(string1, string2, n)
char *string1, *string2; unsigned n;
@strpbrk
strpbrk - Find first occurrence in a string of any character from another string
char *strpbrk(string1, string2)
char *string1, *string2;  
@strspn
strspn - Return length for which one string includes characters in another
unsigned int strspn(string1, string2)
char *string1, *string2;  
@strstr
strstr - Find one string within another
char *strstr(string1, string2)
char *string1, *string2;  
@Super
Super - Enter supervisor mode
long Super(stack) char *stack;
@Supexec
Supexec - Run a function under supervisor mode
#include <osbind.h>
#include <xbios.h>
unsigned long Supexec(address)
int *address;
@Sversion
Sversion - Get the version number of TOS
#include <osbind.h>
int Sversion()
@swab
swab - Swap a pair of bytes
void swab(src, dest, nb) char *src, *dest; unsigned nb;
@system
system - Pass a command to the shell for execution
Pass a command to command.com for execution
Pass a command to TOS for execution
int system(commandline) char *commandline;
@tan
tan - Calculate tangent
#include <math.h>
double tan(radian) double radian;
@tanh
tanh - Calculate hyperbolic cosine
#include <math.h>
double tanh(radian) double radian;
@tempnam
tempnam - Generate a unique name for a temporary file
char *tempnam(directory, name)
char *directory, *name;
@tetd_to_tm
tetd_to_tm - Convert IKBD time to system calendar format
#include <time.h>
tm_t *tetd_to_tm(time) tetd_t time;
@Tgetdate
Tgetdate - Get the current date
#include <osbind.h>
int Tgetdate()
@Tgettime
Tgettime - Get the current time
#include <osbind.h>
int Tgettime()
@Tickcal
Tickcal - Return system timer's calibration.
#include <osbind.h>
#include <bios.h>
long Tickcal()
@time
time - Get current time
#include <time.h>
time_t time(tp) time_t *tp;
@time_to_jday
time_to_jday - Convert system time to Julian date
#include <time.h>
jday_t time_to_jday(time) time_t time;
@tm_to_jday
tm_to_jday - Convert calendar format to Julian time
#include <time.h>
jday_t tm_to_jday(time) tm_t *time;
@tm_to_tetd
tm_to_tetd - Convert system calendar format to IKBD time
#include <time.h>
tetd_t tm_to_tetd(time) tm_t *time;
@tmpnam
tmpnam - Generate a unique name for a temporary file
#include <stdio.h>
char *tmpnam(name) char *name;
@toascii
toascii - Convert characters to ASCII
#include <ctype.h>
int toascii(c) int c;
@tolower
tolower - Convert characters to lower case
int tolower(c) int c;
@_tolower
_tolower - Convert letter to lower case
#include <ctype.h>
int _tolower(c) int c;
@toupper
toupper - Convert characters to upper case
#include <ctype.h>
int toupper(c) int c;
@_toupper
_toupper - Convert letter to upper case
#include <ctype.h>
_toupper(c) int c;
@Tsetdate
Tsetdate - Set a new date
#include <osbind.h>
long Tsetdate(i) inti;
@Tsettime
Tsettime - Set a new time
#include <osbind.h>
long Tsettime(time) int time;
@#undef
#undef - Undefine a manifest constant
#undef variable
@ungetc
ungetc - Return character to input stream
#include <stdio.h>
int ungetc (c, fp) int c; FILE *fp;
@unlink
unlink - Remove a file
int unlink(name) char *name;
@v_arc
v_arc - Draw a circular arc
#include <aesbind.h>
#include <vdibind.h>
void v_arc(handle, x, y, radius, beginangle, endangle)
int handle, x, y, radius, beginangle, endangle;
@v_bar
v_bar - Draw a rectangle
#include <aesbind.h>
#include <vdibind.h>
void v_bar(handle, xyarray) int handle, xyarray[4];
@v_bit_image
v_bit_image - Print a bit image file
#include <aesbind.h>
#include <vdibind.h>
void v_bit_image(handle, filename, aspect, scaling, points, xyarray)
int handle, aspect, scaling, points, xyarray[4]; char *filename;
@v_cellarray
v_cellarray - Draw a table of colored cells
#include <aesbind.h>
#include <vdibind.h>
void v_cellarray(handle, xyarray, rowlength, cells, rows, mode, cellarray)
int handle, xyarray, rowlength[4], cells, rows, mode, cellarray[n ];
@v_circle
v_circle - Draw a circle
#include <aesbind.h>
#include <vdibind.h>
void v_circle(handle, x, y, radius) int handle, x, y, radius;
@v_clear_disp_list
v_clear_disp_list - Clear a printer's display list
#include <aesbind.h>
#include <vdibind.h>
void v_clear_disp_list(handle) int handle;
@v_clrwk
v_clrwk - Clear the virtual workstation
#include <aesbind.h>
#include <vdibind.h>
void v_clrwk(handle) int handle;
@v_clsvwk
v_clsvwk - Close the screen virtual device
#include <aesbind.h>
#include <vdibind.h>
void v_clsvwk(handle) int handle;
@v_clswk
v_clswk - Close a virtual workstation
#include <aesbind.h>
#include <vdibind.h>
void v_clswk(handle) int handle;
@v_contourfill
v_contourfill - Fill an outlined area
#include <aesbind.h>
#include <vdibind.h>
void v_contourfill(handle, x, y, color)
int handle, x, y, color;
@v_curdown
v_curdown - Move text cursor down one row
#include <aesbind.h>
#include <vdibind.h>
void v_curdown(handle) int handle;
@v_curhome
v_curhome - Move text cursor to the home position
#include <aesbind.h>
#include <vdibind.h>
void v_curhome(handle) int handle;
@v_curleft
v_curleft - Move text cursor left one column
#include <aesbind.h>
#include <vdibind.h>
void v_curleft(handle) int handle;
@v_curright
v_curright - Move text cursor right one column
#include <aesbind.h>
#include <vdibind.h>
void v_curright(handle) int handle;
@v_curtext
v_curtext - Write alphabetic text
#include <aesbind.h>
#include <vdibind.h>
void v_curtext(handle, string) int handle; char *string;
@v_curup
v_curup - Move text cursor up one row
#include <aesbind.h>
#include <vdibind.h>
void v_curup(handle) int handle;
@v_dspcur
v_dspcur - Move mouse pointer to point on screen
#include <aesbind.h>
#include <vdibind.h>
void v_dspcur(handle, x, y) int handle, x, y;
@v_eeol
v_eeol - Erase text from cursor to end of screen
#include <aesbind.h>
#include <vdibind.h>
void v_eeol(handle) int handle;
@v_eeos
v_eeos - Erase from text cursor to end of screen
#include <aesbind.h>
#include <vdibind.h>
void v_eeos(handle) int handle;
@v_ellarc
v_ellarc - Draw an elliptical arc
#include <aesbind.h>
#include <vdibind.h>
void v_ellarc(handle, x, y, xradius, yradius, beginangle, endangle)
int handle, x, y, xradius, yradius, beginangle, endangle;
@v_ellipse
v_ellipse - Draw an ellipse
#include <aesbind.h>
#include <vdibind.h>
void v_ellipse(handle, x, y, xradius, yradius)
int handle, x, y, xradius, yradius;
@v_ellpie
v_ellpie - Draw an elliptical pie slice
#include <aesbind.h>
#include <vdibind.h>
void v_ellpie(handle, x, y, xradius, yradius, beginangle, endangle)
int handle, x, y, xradius, yradius, beginangle, endangle;
@v_enter_cur
v_enter_cur - Enter text mode
#include <aesbind.h>
#include <vdibind.h>
void v_enter_cur(handle) int handle;
@v_exit_cur
v_exit_cur - Exit from text mode
#include <aesbind.h>
#include <vdibind.h>
void v_exit_cur(handle) int handle;
@v_fillarea
v_fillarea - Draw a complex polygon
#include <aesbind.h>
#include <vdibind.h>
void v_fillarea(handle, count, xyarray) int handle, count, xyarray[n ];
@v_form_adv
v_form_adv - Advance the page on a printer
#include <aesbind.h>
#include <vdibind.h>
void v_form_adv(handle) int handle;
@v_get_pixel
v_get_pixel - See if a given pixel is set
#include <aesbind.h>
#include <vdibind.h>
void v_get_pixel(handle, x, y, flag, color)
int handle, x, y, *flag, *color;
@v_gtext
v_gtext - Draw graphics text
#include <aesbind.h>
#include <vdibind.h>
void v_gtext(handle, x, y, text) int text, x, y; char *text;
@v_hardcopy
v_hardcopy - Write the screen to a hard-copy device
#include <aesbind.h>
#include <vdibind.h>
void v_hardcopy(handle)
@v_hide_c
v_hide_c - Hide the mouse pointer
#include <aesbind.h>
#include <vdibind.h>
void v_hide_c(handle) int handle;
@v_justified
v_justified - Justify graphics text
#include <aesbind.h>
#include <vdibind.h>
void v_justified(handle, x, y, string, length, charsp, wordsp)
int handle, x, y, length, charsp, wordsp; char *string;
@v_meta_extents
v_meta_extents - Update extents header of metafile
#include <aesbind.h>
#include <vdibind.h>
void v_meta_extents(handle, minx, miny, maxx, maxy)
int handle, minx, miny, maxx, maxy;
@v_opnvwk
v_opnvwk - Open the virtual screen device
#include <aesbind.h>
#include <vdibind.h>
void v_opnvwk(work_in, handle, work_out)
int work_in[11], *handle, work_out[57];
@v_opnwk
v_opnwk - Open a virtual workstation
#include <aesbind.h>
#include <vdibind.h>
void v_opnwk(work_in, handle, work_out)
int work_in[11], *handle, work_out[57];
@v_output_window
v_output_window - Dump a portion of a virtual device to a printer
#include <aesbind.h>
#include <vdibind.h>
void v_output_window(handle, xyarray) int handle, xyarray[4];
@v_pieslice
v_pieslice - Draw a circular pie slice
#include <aesbind.h>
#include <vdibind.h>
void v_pieslice(handle, x, y, radius, beginangle, endangle)
int handle, x, y, radius, beginangle, endangle;
@v_pline
v_pline - Draw a line
#include <aesbind.h>
#include <vdibind.h>
void v_pline(handle, howmany, xyarray)
int handle, howmany, xyarray[n ];
@v_pmarker
v_pmarker - Draw a marker
#include <aesbind.h>
#include <vdibind.h>
void v_pmarker(handle, count, array) int handle, count, array[n ];
@v_rbox
v_rbox - Draw a rounded rectangle
#include <aesbind.h>
#include <vdibind.h>
void v_rbox(handle, xyarray) int handle, xyarray[4];
@v_rfbox
v_rfbox - Draw a filled, rounded rectangle
#include <aesbind.h>
#include <vdibind.h>
void v_rfbox(handle, xyarray) int handle, xyarray[4];
@v_rmcur
v_rmcur - Remove last mouse pointer from the screen
#include <aesbind.h>
#include <vdibind.h>
void v_rmcur(handle) int handle;
@v_rvoff
v_rvoff - End reverse video for alphabetic text
#include <aesbind.h>
#include <vdibind.h>
void v_rvoff(handle) int handle;
@v_rvon
v_rvon - Display alphabetic text in reverse video
#include <aesbind.h>
#include <vdibind.h>
void v_rvon(handle) int handle;
@v_show_c
v_show_c - Show the mouse cursor
#include <aesbind.h>
#include <vdibind.h>
void v_show_c(handle, ignore) int handle, ignore;
@v_updwk
v_updwk - Update a virtual workstation
#include <aesbind.h>
#include <vdibind.h>
void v_updwk(handle) int handle;
@v_write_meta
v_write_meta - Write a metafile item
#include <aesbind.h>
#include <vdibind.h>
void v_write_meta(handle, numintin, intin, numptsin, ptsin)
int handle, numintin, intin[numintin ], numptsin, ptsin[numptsin ];
@vex_butv
vex_butv - Set new button interrupt routine
#include <aesbind.h>
#include <vdibind.h>
void vex_butv(handle, address, oldaddress)
int handle; void (*address); void (*oldaddress);
@vex_curv
vex_curv - Set new cursor interrupt routine
#include <aesbind.h>
#include <vdibind.h>
void vex_curv(handle, address, oldaddress)
int handle; void (*address); void (*oldaddress);
@vex_motv
vex_motv - Set new mouse movement interrupt routine
#include <aesbind.h>
#include <vdibind.h>
void vex_motv(handle, address, oldaddress)
int handle; void (*address); void (*oldaddress);
@vex_timv
vex_timv - Set new timer interrupt routine
#include <aesbind.h>
#include <vdibind.h>
void vex_timv(handle, address, oldaddress, time)
int handle, *time; void (*address); void (*oldaddress);
@vm_filename
vm_filename - Rename a metafile
#include <aesbind.h>
#include <vdibind.h>
void vm_filename(handle, filename) int handle; char *filename;
@vq_cellarray
vq_cellarray - Return information about cell arrays
#include <aesbind.h>
#include <vdibind.h>
void vq_cellarray(handle, xyarray, rowlength, rows,
	cellused, rowused, status, cellarray)
int handle, xyarray, rowlength[4], rows, *cellused, *rowsused, *status, cellarray[n ];
@vq_chcells
vq_chcells - Find how many characters virtual device can print
#include <aesbind.h>
#include <vdibind.h>
void vq_chcells(handle, rows, columns) int handle, *rows, *columns;
@vq_color
vq_color - Check/set color intensity
#include <aesbind.h>
#include <vdibind.h>
void vq_color(handle, color, flag, rgb) int handle, color, flag, rgb[3];
@vq_curaddress
vq_curaddress - Get the text cursor's current position
#include <aesbind.h>
#include <vdibind.h>
void vq_curaddress(handle, row, column) int handle, *row, *column;
@vq_extnd
vq_extnd - Perform extend inquire of VDI virtual device
vq_extend
#include <aesbind.h>
#include <vdibind.h>
void vq_extnd(handle, type, work_out) int handle, type, work_out[57];
@vq_key_s
vq_key_s - Check control key status
#include <aesbind.h>
#include <vdibind.h>
void vq_key_s(handle, status) int handle, *status;
@vq_mouse
vq_mouse - Check mouse position and button state
#include <aesbind.h>
#include <vdibind.h>
void vq_mouse(handle, status, x, y) int handle, *status, *x, *y;
@vq_tabstatus
vq_tabstatus - Find if graphics tablet is available
#include <aesbind.h>
#include <vdibind.h>
void vq_tabstatus(handle) int handle;
@vqf_attributes
vqf_attributes - Read the area fill's current attributes
#include <aesbind.h>
#include <vdibind.h>
void vqf_attributes(handle, attrib) int handle, attrib[5];
@vqin_mode
vqin_mode - Determine mode of a logical input device
#include <aesbind.h>
#include <vdibind.h>
void vqin_mode(handle, device, mode) int handle, device, *mode;
@vql_attributes
vql_attributes - Read the polyline's current attributes
#include <aesbind.h>
#include <vdibind.h>
void vql_attributes(handle, attrib) int handle, attrib[6];
@vqm_attributes
vqm_attributes - Read the marker's current attributes
#include <aesbind.h>
#include <vdibind.h>
void vqm_attributes(handle, attrib) int handle, attrib[5];
@vqp_error
vqp_error - Inquire if an error occurred with the Polaroid Palette
#include <aesbind.h>
#include <vdibind.h>
int vqp_error(handle) int handle;
@vqp_films
vqp_films - Get films supported by driver for Polaroid Palette
#include <aesbind.h>
#include <vdibind.h>
void vqp_films(handle, names) int handle, names[125];
@vqp_state
vqp_state - Read current settings of the Polaroid Palette driver
#include <aesbind.h>
#include <vdibind.h>
void vqp_state(handle, port, film, lightness, interlace, planes, indices);
int handle, *port, *film, *lightness, *interlace, *planes, *indices[8][2];
@vqt_attributes
vqt_attributes - Read the graphic text's current attributes
#include <aesbind.h>
#include <vdibind.h>
void vqt_attributes(handle, attrib) int handle, attrib[10];
@vqt_extent
vqt_extent - Calculate a string's length
#include <aesbind.h>
#include <vdibind.h>
void vqt_extent(handle, text, size) int handle, size[8]; char *text;
@vqt_fontinfo
vqt_fontinfo - Get information about special effects for graphics text
#include <aesbind.h>
#include <vdibind.h>
void vqt_fontinfo(handle, firstchar, lastchar, sizes, maxwidth, adjust)
int handle, *firstchar, *lastchar, sizes[5], *maxwidth, adjust[3];
@vqt_name
vqt_name - Get name and description of graphics text font
#include <aesbind.h>
#include <vdibind.h>
int vqt_name(handle, font, string) int handle, font; char string[32];
@vqt_width
vqt_width - Get character cell width
#include <aesbind.h>
#include <vdibind.h>
int vqt_width(handle, character, width, left, right)
int handle, *width, *left, *right; char character;
@vr_recfl
vr_recfl - Draw a rectangular fill area
#include <aesbind.h>
#include <vdibind.h>
void vr_recfl(handle, xyarray) int handle, xyarray[4];
@vr_trnfm
vr_trnfm - Transform a raster image
#include <aesbind.h>
#include <gemdefs.h>
#include <vdibind.h>
void vr_trnfm(handle, sourcemfdb, destmfdb)
int handle; FDB *sourcemfdb, *destmfdb;
@vro_cpyfm
vro_cpyfm - Copy raster form, opaque
#include <aesbind.h>
#include <gemdefs.h>
#include <vdibind.h>
void vro_cpyfm(handle, logic, xyarray, sourcemfdb, destmfdb)
int handle, logic, xyarray[8]; FDB *sourcemfdb, *destmfdb;
@vrq_choice
vrq_choice - Return status of function keys when any key is pressed
#include <aesbind.h>
#include <vdibind.h>
void vrq_choice(handle, in, out) int handle, in, *out;
@vrq_locator
vrq_locator - Find location of mouse cursor when a key is pressed
#include <aesbind.h>
#include <vdibind.h>
void vrq_locator(handle, x, y, xout, yout, key)
int handle, x, y, *xout, *yout, *key;
@vrq_string
vrq_string - Read a string from the keyboard
#include <aesbind.h>
#include <vdibind.h>
void vrq_string(handle, length, echo, xyarray, string)
int handle, length, echo, xyarray[2]; char *string;
@vrq_valuator
vrq_valuator - Return status of shift and cursor keys
#include <aesbind.h>
#include <vdibind.h>
void vrq_valuator(handle, in, out, key) int handle, in, *out, *key;
@vrt_cpyfm
vrt_cpyfm - Copy raster form, transparent
#include <aesbind.h>
#include <gemdefs.h>
#include <vdibind.h>
void vrt_cpyfm(handle, mode, xyarray, sourcemfdb, destmfdb, color)
int handle, mode, xyarray[8], color[2]; FDB *sourcemfdb, *destmfdb;
@vs_clip
vs_clip - Set the virtual device's clipping rectangle
#include <aesbind.h>
#include <vdibind.h>
void vs_clip(handle, flag, xyarray) int handle, flag, xyarray[4];
@vs_color
vs_color - Set color intensity
#include <aesbind.h>
#include <vdibind.h>
void vs_color(handle, index, rgbarray) int handle, index, rgbarray[3];
@vs_curaddress
vs_curaddress - Move text cursor to specified row and column
#include <aesbind.h>
#include <vdibind.h>
void vs_curaddress(handle, row, column) int handle, row, column;
@vs_palette
vs_palette - Select color palette on medium-resolution screen
#include <aesbind.h>
#include <vdibind.h>
void vs_palette(handle, palette) int handle, palette;
@vsc_form
vsc_form - Draw a new shape for the mouse pointer
#include <aesbind.h>
#include <vdibind.h>
void vsc_form(handle, form) int handle, form[37];
@vsf_color
vsf_color - Set a polygon's fill color
#include <aesbind.h>
#include <vdibind.h>
void vsf_color(handle, color) int handle, color;
@vsf_interior
vsf_interior - Set a polygon's fill type
#include <aesbind.h>
#include <vdibind.h>
void vsf_interior(handle, type) int handle, type;
@vsf_perimeter
vsf_perimeter - Set whether to draw a perimeter around a polygon
#include <aesbind.h>
#include <vdibind.h>
void vsf_perimeter(handle, flag) int handle, flag;
@vsf_style
vsf_style - Set a polygon's fill style
#include <aesbind.h>
#include <vdibind.h>
void vsf_style(handle, style) int handle, style;
@vsf_udpat
vsf_udpat - Define a fill pattern
#include <aesbind.h>
#include <vdibind.h>
void vsf_udpat(handle, pattern, planes) int handle, pattern[n ], planes;
@vsin_mode
vsin_mode - Set input mode for logical input device
#include <aesbind.h>
#include <vdibind.h>
int vsin_mode(handle, device, mode) int handle, device, mode;
@vsl_color
vsl_color - Set a line's color
#include <aesbind.h>
#include <vdibind.h>
int vsl_color(handle, color) int handle, color;
@vsl_ends
vsl_ends - Attach ends to a line
#include <aesbind.h>
#include <vdibind.h>
void vsl_ends(handle, beginning, end) int handle, beginning, end;
@vsl_type
vsl_type - Set a line's type
#include <aesbind.h>
#include <vdibind.h>
int vsl_type(handle, type) int handle, type;
@vsl_udsty
vsl_udsty - Set user-defined line type
#include <aesbind.h>
#include <vdibind.h>
void vsl_udsty(handle, pattern) int handle, pattern;
@vsl_width
vsl_width - Set a line's width
#include <aesbind.h>
#include <vdibind.h>
int vsl_width(handle, width) int handle, width;
@vsm_choice
vsm_choice - Return last function key pressed
#include <aesbind.h>
#include <vdibind.h>
int vsm_choice(handle, key) int handle, *key;
@vsm_color
vsm_color - Set a polymarker's color
#include <aesbind.h>
#include <vdibind.h>
int vsm_color(handle, color) int handle, color;
@vsm_height
vsm_height - Set a polymarker's height
#include <aesbind.h>
#include <vdibind.h>
int vsm_height(handle, height) int handle, height;
@vsm_locator
vsm_locator - Return mouse pointer's position
#include <aesbind.h>
#include <vdibind.h>
int vsm_locator(handle, x, y, xout, yout, key)
int handle, x, y, *xout, *yout, *key;
@vsm_string
vsm_string - Read a string from the keyboard
#include <aesbind.h>
#include <vdibind.h>
int vsm_string(handle, length, echo, xyarray, string)
int handle, length, echo, xyarray[2]; char *string;
@vsm_type
vsm_type - Set polymarker's type
#include <aesbind.h>
#include <vdibind.h>
int vsm_type(handle, type) int handle, type;
@vsm_valuator
vsm_valuator - Return shift/cursor key status
#include <aesbind.h>
#include <vdibind.h>
void vsm_valuator(handle, in, out, key, status)
int handle, in, *out, *key, *status;
@vsp_message
vsp_message - Suppress messages from Polaroid Palette device
#include <aesbind.h>
#include <vdibind.h>
void vsp_message(handle) int handle;
@vsp_save
vsp_save - Save to disk current setting of Polaroid Palette driver
#include <aesbind.h>
#include <vdibind.h>
void vsp_save(handle) int handle;
@vsp_state
vsp_state - Set the Polaroid Palette driver
#include <aesbind.h>
#include <vdibind.h>
void vsp_state(handle, port, film, lightness, interlace, planes, indices);
int handle, port, film, lightness, interlace, lanes, indices[8][2];
@vst_alignment
vst_alignment - Realign graphics text
#include <aesbind.h>
#include <vdibind.h>
void vst_alignment(handle, horiz, vertical, sethoriz, setvert)
int handle, horiz, vertical, *sethoriz, *setvert;
@vst_color
vst_color - Set color for graphics text
#include <aesbind.h>
#include <vdibind.h>
int vst_color(handle, color) int handle, color;
@vst_effects
vst_effects - Set special effects for graphics text
#include <aesbind.h>
#include <vdibind.h>
int vst_effects(handle, effects) int handle, effect;
@vst_font
vst_font - Select a new font
#include <aesbind.h>
#include <vdibind.h>
int vst_font(handle, font) int handle, font;
@vst_height
vst_height - Reset graphics text height, in absolute values
#include <aesbind.h>
#include <vdibind.h>
void vst_height(handle, newheight, charwidth, charheight, cellwidth, cellheight)
int handle, newheight, *charwidth, *charheight, *cellwidth, *cellheight;
@vst_load_fonts
vst_load_fonts - Load fonts other than the standard font
#include <aesbind.h>
#include <vdibind.h>
int vst_load_fonts(handle, reserved) int handle, font;
@vst_point
vst_point - Reset graphics text height, in printer's points
#include <aesbind.h>
#include <vdibind.h>
void vst_point(handle, newheight, charwidth, charheight, cellwidth, cellheight)
int handle, newheight, *charwidth, *charheight, *cellwidth, *cellheight;
@vst_rotation
vst_rotation - Set angle at which graphic text is drawn
#include <aesbind.h>
#include <vdibind.h>
int vst_rotation(handle, angle) int handle, angle;
@vst_unload_fonts
vst_unload_fonts - Unload fonts
#include <aesbind.h>
#include <vdibind.h>
void vst_unload_fonts(handle, reserved) int handle, reserved;
@vswr_mode
vswr_mode - Set the writing mode
#include <aesbind.h>
#include <vdibind.h>
int vswr_mode(handle, mode) int handle, mode;
@Vsync
Vsync - Synchronize with the screen
#include <osbind.h>
#include <xbios.h>
void Vsync()
@wind_calc
wind_calc - Calculate a window's rectangle
#include <aesbind.h>
int wind_calc(type, kind, x, y, w, h, xptr, yptr, wptr, hptr)
int type, x, y, w, h, *xptr, *yptr, *wptr, *hptr; unsigned int kind;
@wind_close
wind_close - Close a window and preserve its handle
#include <aesbind.h>
int wind_close(handle) int handle;
@wind_create
wind_create - Create a window
#include <aesbind.h>
int wind_create(kind, x, y, w, h) unsigned int kind; int x, y, w, h;
@wind_delete
wind_delete - Delete a window and free its resources
#include <aesbind.h>
int wind_delete(handle) int handle;
@wind_find
wind_find - Determine if the mouse pointer is in a window
#include <aesbind.h>
int wind_find(x, y) int x, y;
@wind_get
wind_get - Get information about a window
#include <aesbind.h>
int wind_get(handle, flag, output1, output2, output3, output4)
int handle, flag, *output1, *output2, *output3, *output4;
@wind_open
wind_open - Open or reopen a window
#include <aesbind.h>
int wind_open(handle, x, y, w, h) int handle, x, y, w, h;
@wind_set
wind_set - Set specified fields within the window
#include <aesbind.h>
int wind_set(handle, flag, input1, input2, input3, input4)
int handle, flag, input1, input2, input3, input4;
@wind_update
wind_update - Lock or unlock a window
#include <aesbind.h>
int wind_update(flag) int flag;
@write
write - Write to a file
int write(fd, buffer, n)
int fd; char *buffer; int n;
@xbios
xbios - Call a routine from the extended TOS BIOS
#include <osbind.h>
extern long xbios(n, f1, f2 ... fx);
@Xbtimer
Xbtimer - Initialize the MFP timer
#include <osbind.h>
#include <xbios.h>
void Xbtimer(timer, control, data, buffer)
int timer, control,data; char *buffer;
@
