/*      PROCESS.H

        Process Definition Includes

        Copyright (c) Borland International 1988
        All Rights Reserved.
*/


#if !defined( __PROCESS )
#define __PROCESS


int     exec( char *filename, char *cmdlstr, char *envstr, int *retcode );


#endif

/************************************************************************/
