/*	HELLO.C -- Hello, world */

#include <stdio.h>

int main()
{
    printf("Hello, world\n");
    getchar();
    return 0;
}
