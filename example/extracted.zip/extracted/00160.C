/************************************************************************/
/*                                                                      */
/*    Beispielprogramm:                                 FORM_ALERT()    */
/*                                                      FORM_ERROR()    */
/*                                                      FSEL_INPUT()    */
/*                                                                      */
/*    �ffnen einer Datei mit Fehlerbehandlung.                          */
/*                                                                      */
/*    Copyright (c)  Heimsoeth & Borland  1988                          */
/*                                                                      */
/************************************************************************/

/* -------------------------------------------------------------------- */
/*    Include-Files einbinden.                                          */
/* -------------------------------------------------------------------- */

#include <aes.h>
#include <tos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/* -------------------------------------------------------------------- */
/*    Konstantendefinitionen.                                           */
/* -------------------------------------------------------------------- */

#define MOPENED               0
#define MFSEL                 1
#define MERROR                2
#define STFILELEN            13
#define STPATHLEN            64

#define EOS                  '\0'
#define BACKSLASH            '\\'

/* -------------------------------------------------------------------- */
/*    Funktionsprototypen.                                              */
/* -------------------------------------------------------------------- */

void close_vwork(void);

void test_fkt(void);
void usage(int m);
void build_fname(char *dest, char *s1, char *s2);
FILE *op_fbox(void);

/* -------------------------------------------------------------------- */
/*    Globale Variablen.                                                */
/* -------------------------------------------------------------------- */

char Path[STPATHLEN] = "A:\\*.*";

char *Mess[] =
   {
      "[2][Datei konnte ge�ffnet werden.][Ende|Weiter]",
      "[3][Abbruch der Dateiauswahl.][Ok]"
   };

/* -------------------------------------------------------------------- */
/*    test_fkt()                                          test function */
/*                                                                      */
/*    Funktion, die dem Austesten dient (hier: �ffnen einer Datei mit   */
/*    Fehlerbehandlung).                                                */
/* -------------------------------------------------------------------- */

void test_fkt()
{
   FILE *f;

   while((f = op_fbox()) != NULL)      /* Solange erfolgreich gew�hlt   */
      usage(MOPENED);                  /* wurde weiter.                 */
   usage(MFSEL);                       /* Jetzt aber Schlu�.            */
   fclose(f);                          /* Inputstream schlie�en.        */
}

/* -------------------------------------------------------------------- */
/*    usage()                                                           */
/*                                                                      */
/*    Ausgabe einer vordefinierten Meldung.                             */
/*                                                                      */
/*    int m             Nummer der Meldung.                             */
/* -------------------------------------------------------------------- */

void usage(m)
   int m;
{
   if(m < 2)
   {
      if(form_alert(1, Mess[m]) == 2)  /* Datei ist vorhanden.          */
         return;                       /* Programm fortsetzen.          */
   }
   else                                /* Datei ist nicht vorhanden.    */
      form_error(ENOENT);

   close_vwork();                      /* Sonst Programmabbruch.        */
   exit(1);
}

/* -------------------------------------------------------------------- */
/*    op_fbox()                                       open file via box */
/*                                                                      */
/*    Datei mittels Dateiauswahlbox �ffnen.                             */
/* -------------------------------------------------------------------- */

FILE *op_fbox()
{
   char n[STFILELEN],
        x[STPATHLEN];
   int  b;
   FILE *f = NULL;

   *n = EOS;                           /* Dateinamen l�schen.           */
   Path[0] = (char) Dgetdrv() + 'A';   /* Aktuelles Laufwerk in Pfad.   */
   if(fsel_input(Path, n, &b) == 0)    /* Dateiauswahl.                 */
      usage(MFSEL);                    /* Fehler dabei aufgetreten.     */
   else
   {
      build_fname(x, Path, n);         /* Pfad- und Dateinamen konkat.  */
      if((f = fopen(x, "r")) == NULL)  /* Datei �ffnen.                 */
         usage(MERROR);                /* Fehler dabei aufgetreten.     */
   }
   return(f);                          /* Inputstreampointer zur�ck.    */
}

/* -------------------------------------------------------------------- */
/*    build_fname()                                   build a file name */
/*                                                                      */
/*    Konkatoniere Pfadnamen und Dateinamen.                            */
/*                                                                      */
/*    char *dest        Zielstring.                                     */
/*    char *s1          Pfadname.                                       */
/*    char *s2          Dateiname.                                      */
/* -------------------------------------------------------------------- */

void build_fname(dest, s1, s2)
   char *s1, *s2,
        *dest;
{
   char *cptr;

   cptr = strrchr(s1, BACKSLASH);      /* Letzten Backslash suchen.     */
   while(s1 != cptr)                   /* Bis dorthin Pfad in Ziel-     */
      *dest++ = *s1++;                 /* string kopieren.              */
   *dest++ = BACKSLASH;                /* Backslash anh�ngen.           */
   strcat(dest, s2);                   /* Schlie�lich auch den Datei-   */
}                                      /* namen.                        */

/* -------------------------------------------------------------------- */
/*    Ende der Beispielprogramms f�r FORM_ALERT(), FORM_ERROR() und     */
/*    FSEL_INPUT().                                                     */
/* -------------------------------------------------------------------- */
